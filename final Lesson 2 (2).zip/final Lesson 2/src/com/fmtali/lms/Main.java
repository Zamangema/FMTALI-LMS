package com.fmtali.lms;

import com.fmtali.lms.service.AuthService;
import com.fmtali.lms.service.StudentService;
import com.fmtali.lms.ui.LoginFrame;
import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}

            // Create both services
            AuthService    authService    = new AuthService();
            StudentService studentService = new StudentService();

            // Pass both services to LoginFrame
            new LoginFrame(authService, studentService);
        });
    }
}