package com.fmtali.lms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL =
        "jdbc:postgresql://aws-0-eu-west-1.pooler.supabase.com:5432/postgres?sslmode=require";
    private static final String USER     = "postgres.uerpnfjcaljcjvkayalv";
    private static final String PASSWORD = "@95Makhathini";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("✅ Connected to Supabase");
            return conn;
        } catch (ClassNotFoundException e) {
            System.err.println("❌ Driver not found: " + e.getMessage());
            throw new SQLException("PostgreSQL Driver not found", e);
        }
    }

    public static void closeConnection() {
        System.out.println("ℹ️ Connections are managed automatically");
    }
}