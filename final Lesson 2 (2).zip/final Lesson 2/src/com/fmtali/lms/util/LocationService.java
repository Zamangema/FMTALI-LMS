package com.fmtali.lms.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.NetworkInterface;
import java.net.URL;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class LocationService {

    // FMTALI Randburg coordinates
    private static final double SCHOOL_LAT    = -26.0936;
    private static final double SCHOOL_LON    =  28.0064;
    private static final double MAX_RADIUS_KM =  0.5; // 500 meters

    // All school WiFi network names
    private static final List<String> SCHOOL_WIFI = Arrays.asList(
        "Fmtali_Venus003",
        "Fmtali_Baruk003",
        "Fmtali_KKC003"
    );

    // ── MAIN CHECK ──
    // Returns true only if BOTH WiFi AND location checks pass
    public static boolean isOnCampus() {
        boolean wifiOk     = isOnSchoolWifi();
        boolean locationOk = isWithinSchoolRadius();

        System.out.println("WiFi check: "    + wifiOk);
        System.out.println("Location check: " + locationOk);

        return wifiOk && locationOk;
    }

    // ── WiFi CHECK ──
    // Checks if connected to any of the school WiFi networks
    public static boolean isOnSchoolWifi() {
        try {
            // Run netsh to get current WiFi SSID on Windows
            Process process = Runtime.getRuntime().exec(
                "netsh wlan show interfaces"
            );
            BufferedReader reader = new BufferedReader(
                new InputStreamReader(process.getInputStream())
            );

            String line;
            while ((line = reader.readLine()) != null) {
                // Look for the SSID line
                if (line.trim().startsWith("SSID") &&
                    !line.trim().startsWith("BSSID")) {

                    String ssid = line.split(":")[1].trim();
                    System.out.println("Connected WiFi: " + ssid);

                    // Check if it matches any school WiFi
                    for (String schoolWifi : SCHOOL_WIFI) {
                        if (ssid.equalsIgnoreCase(schoolWifi)) {
                            return true;
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("WiFi check error: " + e.getMessage());
        }
        return false;
    }

    // ── GPS/LOCATION CHECK ──
    // Uses IP geolocation API to estimate location
    public static boolean isWithinSchoolRadius() {
        try {
            // Use free IP geolocation API
            URL url = new URL("http://ip-api.com/json/");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(5000);

            BufferedReader reader = new BufferedReader(
                new InputStreamReader(conn.getInputStream())
            );

            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Parse lat/lon from JSON response manually
            String json = response.toString();
            double lat  = parseJsonDouble(json, "lat");
            double lon  = parseJsonDouble(json, "lon");

            System.out.println("Detected location: " + lat + ", " + lon);

            // Calculate distance from school
            double distance = calculateDistance(lat, lon, SCHOOL_LAT, SCHOOL_LON);
            System.out.println("Distance from school: " + 
                String.format("%.0f", distance * 1000) + " meters");

            return distance <= MAX_RADIUS_KM;

        } catch (Exception e) {
            System.err.println("Location check error: " + e.getMessage());
            return false;
        }
    }

    // ── Haversine formula ──
    // Calculates distance between two GPS coordinates in kilometers
    private static double calculateDistance(double lat1, double lon1,
                                            double lat2, double lon2) {
        final int EARTH_RADIUS_KM = 6371;

        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1))
                 * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);

        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

        return EARTH_RADIUS_KM * c;
    }

    // ── Simple JSON parser for lat/lon ──
    // Avoids needing an external JSON library
    private static double parseJsonDouble(String json, String key) {
        String search = "\"" + key + "\":";
        int start     = json.indexOf(search) + search.length();
        int end        = json.indexOf(",", start);
        if (end == -1) end = json.indexOf("}", start);
        return Double.parseDouble(json.substring(start, end).trim());
    }
}