package com.fmtali.lms.util;

import javax.swing.JOptionPane;
import java.awt.Component;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class ValidationUtil {

    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        if (email == null) return false;
        return email.matches("^[\\w.-]+@[\\w.-]+\\.[a-zA-Z]{2,}$");
    }

    public static void showError(Component parent, String message) {
        JOptionPane.showMessageDialog(parent, message, "Validation Error",
                JOptionPane.ERROR_MESSAGE);
    }

    public static LocalDate parseDate(String dateStr, Component parent) {
        try {
            return LocalDate.parse(dateStr.trim(),
                    DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (DateTimeParseException e) {
            showError(parent, "Invalid date format. Use yyyy-MM-dd (e.g. 2024-01-15)");
            return null;
        }
    }
}