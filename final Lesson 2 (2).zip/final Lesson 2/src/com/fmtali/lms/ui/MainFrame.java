package com.fmtali.lms.ui;

import com.fmtali.lms.model.Role;
import com.fmtali.lms.service.AttendanceService;
import com.fmtali.lms.service.AuthService;
import com.fmtali.lms.service.StudentService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class MainFrame extends JFrame {

    private final StudentService    service           = new StudentService();
    private final AttendanceService attendanceService = new AttendanceService();

    public MainFrame(AuthService authService) {
        setTitle("Student Management System - FMTALI TECHNOLOGY");
        setSize(1100, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        Color darkBg     = new Color(18, 18, 30);
        Color panelBg    = new Color(28, 28, 46);
        Color accentBlue = new Color(72, 130, 255);
        Color accentGold = new Color(255, 196, 64);

        getContentPane().setBackground(darkBg);
        setLayout(new BorderLayout(10, 10));

        // ── Header ──
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(panelBg);

        JPanel titleGroup = new JPanel();
        titleGroup.setLayout(new BoxLayout(titleGroup, BoxLayout.Y_AXIS));
        titleGroup.setBackground(panelBg);

        JLabel titleLbl = new JLabel("  Student Management System");
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLbl.setForeground(accentBlue);

        JLabel subLbl = new JLabel("  Semester 1  —  Academic Year 2025");
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subLbl.setForeground(accentGold);

        String userName = authService.getCurrentUser().getFullName();
        String userRole = authService.getCurrentUser().getRole().name();
        JLabel lblUser  = new JLabel("  Logged in as: "
            + userName + "  [" + userRole + "]");
        lblUser.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblUser.setForeground(new Color(140, 140, 165));

        // Real-time clock
        JLabel lblClock = new JLabel();
        lblClock.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblClock.setForeground(new Color(140, 140, 165));

        Timer clockTimer = new Timer(1000, e -> {
            java.time.LocalDateTime now = java.time.LocalDateTime.now();
            lblClock.setText(now.format(
                java.time.format.DateTimeFormatter
                    .ofPattern("dd MMM yyyy   HH:mm:ss")) + "  ");
        });
        clockTimer.setInitialDelay(0);
        clockTimer.start();

        titleGroup.add(titleLbl);
        titleGroup.add(subLbl);
        titleGroup.add(lblUser);

        // Logo
        JLabel logoLabel = new JLabel();
        logoLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        try {
            ImageIcon originalIcon = new ImageIcon("FMTALI_Logo.png");
            if (originalIcon.getIconWidth() > 0) {
                Image scaled = originalIcon.getImage()
                    .getScaledInstance(180, 55, Image.SCALE_SMOOTH);
                logoLabel.setIcon(new ImageIcon(scaled));
            } else {
                logoLabel.setText("FMTALI TECHNOLOGY");
                logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
                logoLabel.setForeground(accentGold);
            }
        } catch (Exception ex) {
            logoLabel.setText("FMTALI TECHNOLOGY");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
            logoLabel.setForeground(accentGold);
        }

        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, accentGold),
            new EmptyBorder(10, 20, 10, 20)
        ));
        header.add(titleGroup, BorderLayout.WEST);
        header.add(lblClock,   BorderLayout.CENTER);
        header.add(logoLabel,  BorderLayout.EAST);

        // ── Core panels ──
        DashboardPanel dashboard  = new DashboardPanel(service);
        TablePanel     tablePanel = new TablePanel(service);
        FormPanel      formPanel  = new FormPanel(service, tablePanel,
                                                  authService);
        tablePanel.setFormPanel(formPanel);
        tablePanel.setDashboardPanel(dashboard);

        // ── Role-based UI control ──
        Role   role       = authService.getCurrentUser().getRole();
        String viewerRole = role.name();
        formPanel.setRole(viewerRole);

        // ── Students tab ──
        JPanel studentsTab = new JPanel(new BorderLayout(10, 10));
        studentsTab.setBackground(darkBg);
        studentsTab.add(dashboard,  BorderLayout.NORTH);
        studentsTab.add(formPanel,  BorderLayout.WEST);
        studentsTab.add(tablePanel, BorderLayout.CENTER);

        // ── Attendance tab ──
        AttendancePanel attendancePanel =
            new AttendancePanel(attendanceService, viewerRole);

        // ── Tabbed pane ──
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(panelBg);
        tabs.setForeground(accentGold);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.addTab("  Students  ",   studentsTab);
        tabs.addTab("  Attendance  ", attendancePanel);

        // ✅ Admin Panel tab — only visible to ADMIN
        if (role == Role.ADMIN) {
            JPanel adminPanel = buildAdminPanel(authService,
                darkBg, panelBg, accentBlue, accentGold);
            tabs.addTab("  Admin Panel  ", adminPanel);
        }

        // ── Bottom bar ──
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        bottomBar.setBackground(panelBg);

        JLabel tip = new JLabel(
            "Tip: Click a row to select a student, then use Update or Delete.");
        tip.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tip.setForeground(new Color(140, 140, 165));

        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnLogout.setBackground(new Color(210, 70, 70));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                clockTimer.stop();
                authService.logout();
                dispose();
                new LoginFrame(authService, new StudentService());
            }
        });

        JPanel bottomRight = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomRight.setBackground(panelBg);
        bottomRight.add(btnLogout);

        bottomBar.setLayout(new BorderLayout());
        bottomBar.add(tip,         BorderLayout.WEST);
        bottomBar.add(bottomRight, BorderLayout.EAST);

        add(header,    BorderLayout.NORTH);
        add(tabs,      BorderLayout.CENTER);
        add(bottomBar, BorderLayout.SOUTH);

        setVisible(true);
    }

    // ── BUILD ADMIN PANEL ──
    private JPanel buildAdminPanel(AuthService authService,
                                   Color darkBg, Color panelBg,
                                   Color accentBlue, Color accentGold) {
        Color textWhite = new Color(230, 230, 240);
        Color textGray  = new Color(140, 140, 165);
        Color rowEven   = new Color(34, 34, 56);
        Color rowOdd    = new Color(40, 40, 65);

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(darkBg);
        panel.setBorder(new EmptyBorder(10, 12, 10, 12));

        // ── TOP: Change Own Password ──
        JPanel pwPanel = new JPanel(new BorderLayout(0, 8));
        pwPanel.setBackground(panelBg);
        pwPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentBlue, 1, true),
            new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel pwTitle = new JLabel("Change My Password");
        pwTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        pwTitle.setForeground(accentGold);

        JPanel pwFields = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 6));
        pwFields.setBackground(panelBg);

        JPasswordField txtCurrent = makePassField(160);
        JPasswordField txtNew     = makePassField(160);
        JPasswordField txtConfirm = makePassField(160);

        JLabel lblPwStatus = new JLabel(" ");
        lblPwStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblPwStatus.setForeground(new Color(80, 200, 120));

        JButton btnChangePw = makeAdminButton(
            "Update Password", new Color(72, 130, 255), 160);

        btnChangePw.addActionListener(e -> {
            String current = new String(txtCurrent.getPassword());
            String newPw   = new String(txtNew.getPassword());
            String confirm = new String(txtConfirm.getPassword());

            // Validate current password
            if (current.isEmpty() || newPw.isEmpty() || confirm.isEmpty()) {
                lblPwStatus.setForeground(new Color(220, 80, 80));
                lblPwStatus.setText("All fields are required.");
                return;
            }
            if (!newPw.equals(confirm)) {
                lblPwStatus.setForeground(new Color(220, 80, 80));
                lblPwStatus.setText("New passwords do not match.");
                return;
            }
            if (newPw.length() < 4) {
                lblPwStatus.setForeground(new Color(220, 80, 80));
                lblPwStatus.setText("Password must be at least 4 characters.");
                return;
            }

            // Verify current password is correct
            String adminUsername = authService.getCurrentUser().getId();
            User   adminUser     = authService.findById(adminUsername);

            if (adminUser == null || !com.fmtali.lms.util.PasswordUtil
                    .verify(current, adminUser.getPasswordHash())) {
                lblPwStatus.setForeground(new Color(220, 80, 80));
                lblPwStatus.setText("Current password is incorrect.");
                return;
            }

            // Change password
            boolean ok = authService.changePassword(adminUsername, newPw);
            if (ok) {
                lblPwStatus.setForeground(new Color(80, 200, 120));
                lblPwStatus.setText("✅ Password changed successfully!");
                txtCurrent.setText("");
                txtNew.setText("");
                txtConfirm.setText("");
            } else {
                lblPwStatus.setForeground(new Color(220, 80, 80));
                lblPwStatus.setText("❌ Failed to change password.");
            }
        });

        pwFields.add(makeFieldLabel("Current Password:", textGray));
        pwFields.add(txtCurrent);
        pwFields.add(makeFieldLabel("New Password:", textGray));
        pwFields.add(txtNew);
        pwFields.add(makeFieldLabel("Confirm New:", textGray));
        pwFields.add(txtConfirm);
        pwFields.add(btnChangePw);
        pwFields.add(lblPwStatus);

        pwPanel.add(pwTitle,   BorderLayout.NORTH);
        pwPanel.add(pwFields,  BorderLayout.CENTER);

        // ── BOTTOM: User Management ──
        JPanel userPanel = new JPanel(new BorderLayout(0, 8));
        userPanel.setBackground(panelBg);
        userPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentGold, 1, true),
            new EmptyBorder(14, 16, 14, 16)
        ));

        JLabel userTitle = new JLabel("User Management");
        userTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        userTitle.setForeground(accentGold);

        // Add user form
        JPanel addUserForm = new JPanel(new FlowLayout(FlowLayout.LEFT,
            10, 6));
        addUserForm.setBackground(panelBg);

        JTextField txtNewUsername = makeAdminField(130);
        JTextField txtNewFullName = makeAdminField(160);
        JComboBox<String> cmbNewRole = new JComboBox<>(
            new String[]{"FACILITATOR", "ADMIN"});
        styleAdminCombo(cmbNewRole, textWhite);

        JLabel lblAddStatus = new JLabel(" ");
        lblAddStatus.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblAddStatus.setForeground(new Color(80, 200, 120));

        JButton btnAddUser = makeAdminButton(
            "Add User", new Color(80, 170, 110), 110);

        // Users table
        String[] cols = {"Username", "Full Name", "Role",
                         "First Login", "Action"};
        DefaultTableModel userTableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        JTable userTable = new JTable(userTableModel);
        userTable.setBackground(rowEven);
        userTable.setForeground(textWhite);
        userTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        userTable.setRowHeight(28);
        userTable.setShowGrid(false);
        userTable.setIntercellSpacing(new Dimension(0, 1));
        userTable.setSelectionBackground(accentBlue);
        userTable.setSelectionForeground(Color.WHITE);
        userTable.getTableHeader().setBackground(new Color(22, 22, 40));
        userTable.getTableHeader().setForeground(accentGold);
        userTable.getTableHeader().setFont(
            new Font("Segoe UI", Font.BOLD, 13));
        userTable.getTableHeader().setReorderingAllowed(false);

        // Custom renderer
        userTable.setDefaultRenderer(Object.class,
            new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(
                        JTable t, Object val, boolean sel,
                        boolean foc, int row, int col) {
                    super.getTableCellRendererComponent(
                        t, val, sel, foc, row, col);
                    setBorder(new EmptyBorder(0, 8, 0, 8));
                    if (!sel) {
                        setBackground(row % 2 == 0 ? rowEven : rowOdd);
                        setForeground(textWhite);
                        // Color role column
                        if (col == 2 && val != null) {
                            if (val.toString().equals("ADMIN")) {
                                setForeground(accentGold);
                            } else if (val.toString().equals("FACILITATOR")) {
                                setForeground(new Color(100, 180, 255));
                            } else {
                                setForeground(new Color(80, 200, 120));
                            }
                        }
                    }
                    return this;
                }
            });

        int[] widths = {120, 180, 110, 90, 80};
        for (int i = 0; i < widths.length; i++)
            userTable.getColumnModel().getColumn(i)
                .setPreferredWidth(widths[i]);

        // Load users into table
        Runnable loadUsers = () -> {
            userTableModel.setRowCount(0);
            for (com.fmtali.lms.model.User u : authService.getAllUsers()) {
                // Only show ADMIN and FACILITATOR in this table
                if (u.getRole() == Role.ADMIN
                        || u.getRole() == Role.FACILITATOR) {
                    userTableModel.addRow(new Object[]{
                        u.getId(),
                        u.getFullName(),
                        u.getRole().name(),
                        u.isFirstLogin() ? "Yes" : "No",
                        "Select"
                    });
                }
            }
        };
        loadUsers.run();

        // Buttons for selected user
        JPanel selectedUserPanel = new JPanel(
            new FlowLayout(FlowLayout.LEFT, 8, 4));
        selectedUserPanel.setBackground(panelBg);

        JLabel lblSelectedUser = new JLabel("Select a user from table:");
        lblSelectedUser.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblSelectedUser.setForeground(textGray);

        JButton btnResetPw = makeAdminButton(
            "Reset Password", new Color(255, 140, 60), 140);
        JButton btnDeleteUser = makeAdminButton(
            "Delete User", new Color(210, 70, 70), 120);
        JLabel lblActionStatus = new JLabel(" ");
        lblActionStatus.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblActionStatus.setForeground(new Color(80, 200, 120));

        // Reset password — resets to their username as password
        btnResetPw.addActionListener(e -> {
            int row = userTable.getSelectedRow();
            if (row < 0) {
                lblActionStatus.setForeground(new Color(220, 80, 80));
                lblActionStatus.setText("Select a user first.");
                return;
            }
            String username = userTableModel
                .getValueAt(row, 0).toString();

            // Don't allow resetting your own password here
            if (username.equalsIgnoreCase(
                    authService.getCurrentUser().getId())) {
                lblActionStatus.setForeground(new Color(220, 80, 80));
                lblActionStatus.setText(
                    "Use 'Change My Password' above for your own password.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                "Reset password for \"" + username + "\"?\n"
                + "Their password will be reset to: " + username,
                "Confirm Reset", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                // Reset password = their username, first_login = true
                authService.resetPassword(username);
                lblActionStatus.setForeground(new Color(80, 200, 120));
                lblActionStatus.setText(
                    "✅ Password reset for: " + username);
                loadUsers.run();
            }
        });

        // Delete user account
        btnDeleteUser.addActionListener(e -> {
            int row = userTable.getSelectedRow();
            if (row < 0) {
                lblActionStatus.setForeground(new Color(220, 80, 80));
                lblActionStatus.setText("Select a user first.");
                return;
            }
            String username = userTableModel
                .getValueAt(row, 0).toString();

            // Protect — can't delete yourself
            if (username.equalsIgnoreCase(
                    authService.getCurrentUser().getId())) {
                lblActionStatus.setForeground(new Color(220, 80, 80));
                lblActionStatus.setText(
                    "You cannot delete your own account!");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                "Delete account: \"" + username + "\"?\n"
                + "This cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                authService.deleteAccount(username);
                lblActionStatus.setForeground(new Color(80, 200, 120));
                lblActionStatus.setText("✅ Account deleted: " + username);
                loadUsers.run();
            }
        });

        // Add new user button action
        btnAddUser.addActionListener(e -> {
            String username = txtNewUsername.getText().trim();
            String fullName = txtNewFullName.getText().trim();
            String roleStr  = (String) cmbNewRole.getSelectedItem();

            if (username.isEmpty() || fullName.isEmpty()) {
                lblAddStatus.setForeground(new Color(220, 80, 80));
                lblAddStatus.setText("Username and Full Name required.");
                return;
            }

            Role newRole = Role.valueOf(roleStr);
            boolean ok   = authService.createAccount(
                username, fullName, newRole);

            if (ok) {
                lblAddStatus.setForeground(new Color(80, 200, 120));
                lblAddStatus.setText("✅ Account created: " + username
                    + " | Default password: " + username);
                txtNewUsername.setText("");
                txtNewFullName.setText("");
                loadUsers.run();
            } else {
                lblAddStatus.setForeground(new Color(220, 80, 80));
                lblAddStatus.setText(
                    "❌ Username already exists: " + username);
            }
        });

        selectedUserPanel.add(lblSelectedUser);
        selectedUserPanel.add(btnResetPw);
        selectedUserPanel.add(btnDeleteUser);
        selectedUserPanel.add(lblActionStatus);

        addUserForm.add(makeFieldLabel("Username:", textGray));
        addUserForm.add(txtNewUsername);
        addUserForm.add(makeFieldLabel("Full Name:", textGray));
        addUserForm.add(txtNewFullName);
        addUserForm.add(makeFieldLabel("Role:", textGray));
        addUserForm.add(cmbNewRole);
        addUserForm.add(btnAddUser);
        addUserForm.add(lblAddStatus);

        JScrollPane userScroll = new JScrollPane(userTable);
        userScroll.getViewport().setBackground(rowEven);
        userScroll.setBorder(
            BorderFactory.createLineBorder(accentBlue, 1));

        JPanel userBottom = new JPanel(new BorderLayout(0, 6));
        userBottom.setBackground(panelBg);
        userBottom.add(selectedUserPanel, BorderLayout.NORTH);
        userBottom.add(userScroll,        BorderLayout.CENTER);

        userPanel.add(userTitle,   BorderLayout.NORTH);
        userPanel.add(addUserForm, BorderLayout.CENTER);
        userPanel.add(userBottom,  BorderLayout.SOUTH);

        // Stack top and bottom
        JPanel centerStack = new JPanel(new GridLayout(2, 1, 0, 10));
        centerStack.setBackground(darkBg);
        centerStack.add(pwPanel);
        centerStack.add(userPanel);

        panel.add(centerStack, BorderLayout.CENTER);
        return panel;
    }

    // ── UI Helpers ──
    private JPasswordField makePassField(int width) {
        JPasswordField pf = new JPasswordField();
        pf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        pf.setBackground(new Color(45, 45, 70));
        pf.setForeground(new Color(230, 230, 240));
        pf.setCaretColor(new Color(230, 230, 240));
        pf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(5, 8, 5, 8)
        ));
        pf.setPreferredSize(new Dimension(width, 32));
        return pf;
    }

    private JTextField makeAdminField(int width) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBackground(new Color(45, 45, 70));
        tf.setForeground(new Color(230, 230, 240));
        tf.setCaretColor(new Color(230, 230, 240));
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(5, 8, 5, 8)
        ));
        tf.setPreferredSize(new Dimension(width, 32));
        return tf;
    }

    private JButton makeAdminButton(String text, Color bg, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(width, 32));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(bg.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private JLabel makeFieldLabel(String text, Color color) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(color);
        return l;
    }

    private void styleAdminCombo(JComboBox<String> cb, Color textColor) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(new Color(45, 45, 70));
        cb.setForeground(textColor);
        cb.setPreferredSize(new Dimension(130, 32));
    }
}