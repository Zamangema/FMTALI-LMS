package com.fmtali.lms.ui;

import com.fmtali.lms.service.AuthService;
import com.fmtali.lms.util.PasswordUtil;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class ChangePasswordDialog extends JDialog {

    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);

    private JPasswordField txtNew;
    private JPasswordField txtConfirm;
    private JLabel         lblStrength;
    private boolean        passwordChanged = false;

    private final AuthService authService;
    private final String      userId;

    public ChangePasswordDialog(Frame parent, AuthService authService, String userId) {
        super(parent, "Change Password", true);

        this.authService = authService;
        this.userId = userId;

        buildUI(); 

        // FIX: Force clear and spacious sizing dimensions that can't be cut off
        setMinimumSize(new Dimension(480, 580));
        setPreferredSize(new Dimension(480, 580));
        setSize(480, 580);

        setLocationRelativeTo(parent);
        setResizable(true);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
    }

    private void buildUI() {
        JPanel outer = new JPanel(new BorderLayout());
        outer.setBackground(panelBg);
        outer.setBorder(new EmptyBorder(20, 25, 20, 25));
        setContentPane(outer);

        // Inputs panel using vertical stacking rules
        JPanel content = new JPanel();
        content.setBackground(panelBg);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));

        // Header Title
        JLabel title = new JLabel("Set Your New Password");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(accentGold);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(title);
        content.add(Box.createVerticalStrut(6));

        // Description
        JLabel subtitle = new JLabel("You must change your password before continuing.");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(textGray);
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(subtitle);
        content.add(Box.createVerticalStrut(14));

        // Requirements Box
        JPanel rulesBox = new JPanel();
        rulesBox.setLayout(new BoxLayout(rulesBox, BoxLayout.Y_AXIS));
        rulesBox.setBackground(new Color(35, 35, 55));
        rulesBox.setBorder(new EmptyBorder(10, 12, 10, 12));
        rulesBox.setAlignmentX(Component.LEFT_ALIGNMENT);
        rulesBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 130));
        
        rulesBox.add(ruleLabel("• At least 8 characters"));
        rulesBox.add(Box.createVerticalStrut(3));
        rulesBox.add(ruleLabel("• At least one uppercase letter (A-Z)"));
        rulesBox.add(Box.createVerticalStrut(3));
        rulesBox.add(ruleLabel("• At least one number (0-9)"));
        rulesBox.add(Box.createVerticalStrut(3));
        rulesBox.add(ruleLabel("• At least one special character (!@#$%)"));
        rulesBox.add(Box.createVerticalStrut(3));
        rulesBox.add(ruleLabel("• Not the same as your ID number"));
        content.add(rulesBox);
        content.add(Box.createVerticalStrut(20));

        // Password input field
        content.add(fieldLabel("New Password"));
        content.add(Box.createVerticalStrut(5));
        txtNew = makePasswordField();
        content.add(txtNew);
        content.add(Box.createVerticalStrut(14));

        // Confirmation input field
        content.add(fieldLabel("Confirm Password"));
        content.add(Box.createVerticalStrut(5));
        txtConfirm = makePasswordField();
        content.add(txtConfirm);
        content.add(Box.createVerticalStrut(10));

        // Metrics output label
        lblStrength = new JLabel(" ");
        lblStrength.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblStrength.setForeground(textGray);
        lblStrength.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(lblStrength);

        // Real-time strength calculation handlers
        txtNew.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) { checkStrength(); }
        });
        txtConfirm.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                    handleChange();
            }
        });

        // Wrap data inputs securely inside a scrollable pane context
        JScrollPane scrollPane = new JScrollPane(content);
        scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setBackground(panelBg);
        outer.add(scrollPane, BorderLayout.CENTER);

        // ── FIXED ACTION AREA: Pinned rigidly to SOUTH zone ──
        JButton btnConfirm = new JButton("Set New Password & Continue");
        btnConfirm.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnConfirm.setBackground(Color.GREEN);
        btnConfirm.setForeground(Color.WHITE);
        btnConfirm.setFocusPainted(false);
        btnConfirm.setBorderPainted(false);
        btnConfirm.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnConfirm.setPreferredSize(new Dimension(400, 48));
        btnConfirm.addActionListener(e -> handleChange());

        JPanel btnWrapper = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 12));
        btnWrapper.setBackground(panelBg);
        btnWrapper.add(btnConfirm);
        
        outer.add(btnWrapper, BorderLayout.SOUTH);
    }

    private void checkStrength() {
        String pw = new String(txtNew.getPassword());
        if (pw.isEmpty()) {
            lblStrength.setText(" ");
            return;
        }
        if (PasswordUtil.isStrongPassword(pw)) {
            lblStrength.setText("✓ Strong password");
            lblStrength.setForeground(new Color(80, 200, 120));
        } else {
            lblStrength.setText("✗ Too weak — check the rules above");
            lblStrength.setForeground(new Color(220, 80, 80));
        }
    }

    private void handleChange() {
        String newPw     = new String(txtNew.getPassword());
        String confirmPw = new String(txtConfirm.getPassword());

        if (newPw.isEmpty() || confirmPw.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in both password fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!newPw.equals(confirmPw)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (PasswordUtil.isSameAsID(newPw, userId)) {
            JOptionPane.showMessageDialog(this, "Password cannot be the same as your ID number.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!PasswordUtil.isStrongPassword(newPw)) {
            JOptionPane.showMessageDialog(this, PasswordUtil.getPasswordRules(), "Weak Password", JOptionPane.WARNING_MESSAGE);
            return;
        }

        authService.changePassword(userId, newPw);
        passwordChanged = true;
        JOptionPane.showMessageDialog(this, "Password successfully updated!", "Success", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }

    public boolean isPasswordChanged() {
        return passwordChanged;
    }

    private JLabel ruleLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lbl.setForeground(textGray);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JLabel fieldLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lbl.setForeground(textWhite);
        lbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        return lbl;
    }

    private JPasswordField makePasswordField() {
        JPasswordField pf = new JPasswordField();
        pf.setBackground(new Color(40, 40, 65));
        pf.setForeground(Color.WHITE);
        pf.setCaretColor(Color.WHITE);
        pf.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(60, 60, 90), 1),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)
        ));
        pf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 35));
        pf.setAlignmentX(Component.LEFT_ALIGNMENT);
        return pf;
    }
}
