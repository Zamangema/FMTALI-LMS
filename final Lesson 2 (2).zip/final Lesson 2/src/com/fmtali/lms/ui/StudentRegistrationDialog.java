package com.fmtali.lms.ui;

import com.fmtali.lms.model.Role;
import com.fmtali.lms.service.AuthService;
import com.fmtali.lms.service.StudentService;
import com.fmtali.lms.model.Student;
import com.fmtali.lms.util.LocationService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class StudentRegistrationDialog extends JDialog {

    private final Color darkBg     = new Color(18, 18, 30);
    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);
    private final Color accentGreen= new Color(60, 180, 100);

    private JTextField txtStudentID;
    private JTextField txtFullName;
    private JTextField txtEmail;
    private JComboBox<String> cmbCourse;
    private JLabel lblStatus;

    private final AuthService    authService;
    private final StudentService studentService;

    private boolean registered = false;

    public StudentRegistrationDialog(JFrame parent,
                                     AuthService authService,
                                     StudentService studentService) {
        super(parent, "Student Self-Registration", true);
        this.authService    = authService;
        this.studentService = studentService;
        buildUI();
        setSize(460, 560);
        setLocationRelativeTo(parent);
        setResizable(false);
    }

    private void buildUI() {
        getContentPane().setBackground(darkBg);
        setLayout(new GridBagLayout());

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(panelBg);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentBlue, 1, true),
            new EmptyBorder(24, 28, 24, 28)
        ));

        // Title
        JLabel title = new JLabel("Student Registration");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(accentGold);
        title.setAlignmentX(CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("You must be on FMTALI campus to register");
        subtitle.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        subtitle.setForeground(textGray);
        subtitle.setAlignmentX(CENTER_ALIGNMENT);

        card.add(title);
        card.add(Box.createVerticalStrut(4));
        card.add(subtitle);
        card.add(Box.createVerticalStrut(20));

        // Student ID field
        card.add(makeLabel("SA ID Number (will be your username)"));
        txtStudentID = makeTextField();
        card.add(txtStudentID);
        card.add(Box.createVerticalStrut(10));

        // Full Name field
        card.add(makeLabel("Full Name"));
        txtFullName = makeTextField();
        card.add(txtFullName);
        card.add(Box.createVerticalStrut(10));

        // Email field
        card.add(makeLabel("Email Address"));
        txtEmail = makeTextField();
        card.add(txtEmail);
        card.add(Box.createVerticalStrut(10));

        // Course dropdown
        card.add(makeLabel("Select Course"));
        String[] courses = { "Java", "Power BI", "Azure-900", "AI-900" };
        cmbCourse = new JComboBox<>(courses);
        cmbCourse.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cmbCourse.setBackground(new Color(45, 45, 70));
        cmbCourse.setForeground(textWhite);
        cmbCourse.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        cmbCourse.setAlignmentX(LEFT_ALIGNMENT);
        card.add(cmbCourse);
        card.add(Box.createVerticalStrut(16));

        // Status label
        lblStatus = new JLabel(" ");
        lblStatus.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblStatus.setForeground(new Color(220, 80, 80));
        lblStatus.setAlignmentX(CENTER_ALIGNMENT);
        lblStatus.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));
        card.add(lblStatus);
        card.add(Box.createVerticalStrut(10));

        // Register button
        JButton btnRegister = makeButton("VERIFY LOCATION & REGISTER", accentGreen);
        btnRegister.addActionListener(e -> handleRegistration());
        card.add(btnRegister);
        card.add(Box.createVerticalStrut(10));

        // Cancel button
        JButton btnCancel = makeButton("Cancel", new Color(90, 90, 120));
        btnCancel.addActionListener(e -> dispose());
        card.add(btnCancel);
        card.add(Box.createVerticalStrut(14));

        // Info note
        JLabel note = new JLabel("<html><center>Your default password will be your ID number.<br>"
            + "You will be asked to change it on first login.</center></html>");
        note.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        note.setForeground(textGray);
        note.setAlignmentX(CENTER_ALIGNMENT);
        card.add(note);

        add(card);
    }

    // ── Handle Registration ──
    private void handleRegistration() {
        String id     = txtStudentID.getText().trim();
        String name   = txtFullName.getText().trim();
        String email  = txtEmail.getText().trim();
        String course = (String) cmbCourse.getSelectedItem();

        // Validate fields first
        if (id.isEmpty()) {
            showError("SA ID Number is required.");
            return;
        }
        if (name.isEmpty()) {
            showError("Full Name is required.");
            return;
        }
        if (email.isEmpty() || !email.contains("@")) {
            showError("Please enter a valid email address.");
            return;
        }

        // Check if student ID already exists
        if (studentService.studentIDExists(id)) {
            showError("A student with that ID already exists.");
            return;
        }

        // Show checking message
        lblStatus.setForeground(accentGold);
        lblStatus.setText("Checking your location and WiFi...");

        // Run location check in background so UI doesn't freeze
        SwingWorker<Boolean, Void> locationWorker = new SwingWorker<>() {
            @Override
            protected Boolean doInBackground() {
                return LocationService.isOnCampus();
            }

            @Override
            protected void done() {
                try {
                    boolean onCampus = get();

                    if (!onCampus) {
                        // Check which one failed for a better error message
                        boolean wifiOk = LocationService.isOnSchoolWifi();
                        boolean gpsOk  = LocationService.isWithinSchoolRadius();

                        if (!wifiOk && !gpsOk) {
                            showError("<html><center>Registration failed!<br>"
                                + "You must be on FMTALI WiFi and within 500m of campus.</center></html>");
                        } else if (!wifiOk) {
                            showError("<html><center>Not connected to FMTALI WiFi.<br>"
                                + "Please connect to Fmtali_Venus003, Fmtali_Baruk003,<br>"
                                + "or Fmtali_KKC003 and try again.</center></html>");
                        } else {
                            showError("<html><center>You are not within 500m of FMTALI campus.<br>"
                                + "You must be physically on campus to register.</center></html>");
                        }
                        return;
                    }

                    // Location check passed — create the accounts
                    completeRegistration(id, name, email, course);

                } catch (Exception e) {
                    showError("Location check failed: " + e.getMessage());
                }
            }
        };

        locationWorker.execute();
    }

    // ── Complete Registration ──
    // Called only after location check passes
    private void completeRegistration(String id, String name,
                                      String email, String course) {
        // 1. Create student record in students table
        Student newStudent = new Student(
            id, name, email, course,
            LocalDate.now(), "Active"
        );
        studentService.addStudent(newStudent);

        // 2. Create login account in users table
        // Default password = their student ID, first_login = true
        authService.createAccount(id, name, com.fmtali.lms.model.Role.STUDENT);

        // Show success
        registered = true;
        lblStatus.setForeground(accentGreen);
        lblStatus.setText("Registration successful!");

        JOptionPane.showMessageDialog(this,
            "Welcome, " + name + "!\n\n"
            + "Your account has been created.\n"
            + "Username: " + id + "\n"
            + "Password: " + id + " (change this on first login)",
            "Registration Successful",
            JOptionPane.INFORMATION_MESSAGE);

        dispose();
    }

    // ── Helper: show error ──
    private void showError(String msg) {
        lblStatus.setForeground(new Color(220, 80, 80));
        lblStatus.setText(msg);
    }

    public boolean isRegistered() { return registered; }

    // ── UI Helpers ──
    private JLabel makeLabel(String text) {
        JLabel lbl = new JLabel(text);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        lbl.setForeground(textGray);
        lbl.setAlignmentX(LEFT_ALIGNMENT);
        return lbl;
    }

    private JTextField makeTextField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBackground(new Color(45, 45, 70));
        tf.setForeground(textWhite);
        tf.setCaretColor(textWhite);
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(8, 10, 8, 10)
        ));
        tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        tf.setAlignmentX(LEFT_ALIGNMENT);
        return tf;
    }

    private JButton makeButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { btn.setBackground(bg.brighter()); }
            public void mouseExited(MouseEvent e)  { btn.setBackground(bg); }
        });
        return btn;
    }
}