package com.fmtali.lms.ui;

import com.fmtali.lms.model.User;
import com.fmtali.lms.service.AuthService;
import com.fmtali.lms.service.StudentService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {

    private final Color darkBg     = new Color(18, 18, 30);
    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);
    private final Color accentGreen= new Color(60, 180, 100);

    private JTextField     txtID;
    private JPasswordField txtPassword;
    private JLabel         lblError;

    private final AuthService    authService;
    private final StudentService studentService;

    public LoginFrame(AuthService authService, StudentService studentService) {
        this.authService    = authService;
        this.studentService = studentService;
        buildUI();
        setTitle("FMTALI LMS — Login");
        setSize(440, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    private void buildUI() {
        getContentPane().setBackground(darkBg);
        setLayout(new GridBagLayout());

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(panelBg);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentBlue, 1, true),
            new EmptyBorder(28, 32, 28, 32)
        ));

        // ── Logo / title ──
        JLabel logoText = new JLabel("FMTALI");
        logoText.setFont(new Font("Segoe UI", Font.BOLD, 34));
        logoText.setForeground(accentGold);
        logoText.setAlignmentX(CENTER_ALIGNMENT);

        JLabel subText = new JLabel("Technology & Leadership Institute");
        subText.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subText.setForeground(textGray);
        subText.setAlignmentX(CENTER_ALIGNMENT);

        JLabel systemText = new JLabel("Learning Management System");
        systemText.setFont(new Font("Segoe UI", Font.BOLD, 13));
        systemText.setForeground(accentBlue);
        systemText.setAlignmentX(CENTER_ALIGNMENT);

        // ── ID field ──
        JLabel lblID = fieldLabel("ID Number / Username");
        txtID = makeTextField();

        // ── Password field ──
        JLabel lblPw = fieldLabel("Password");
        txtPassword = new JPasswordField();
        styleField(txtPassword);

        // ── Error label ──
        lblError = new JLabel(" ");
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblError.setForeground(new Color(220, 80, 80));
        lblError.setAlignmentX(CENTER_ALIGNMENT);
        lblError.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));

        // ── Login button ──
        JButton btnLogin = new JButton("LOGIN");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnLogin.setBackground(accentBlue);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBorderPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btnLogin.setAlignmentX(LEFT_ALIGNMENT);
        btnLogin.addActionListener(e -> handleLogin());
        btnLogin.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnLogin.setBackground(accentBlue.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btnLogin.setBackground(accentBlue);
            }
        });

        // Press Enter to login
        txtPassword.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) handleLogin();
            }
        });

        // ── Register button (students only) ──
        JButton btnRegister = new JButton("New Student? Register Here");
        btnRegister.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        btnRegister.setBackground(new Color(35, 35, 58));
        btnRegister.setForeground(accentGreen);
        btnRegister.setFocusPainted(false);
        btnRegister.setBorderPainted(false);
        btnRegister.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnRegister.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        btnRegister.setAlignmentX(LEFT_ALIGNMENT);
        btnRegister.addActionListener(e -> openRegistration());
        btnRegister.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnRegister.setForeground(accentGreen.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btnRegister.setForeground(accentGreen);
            }
        });

        // ── Hint ──
        JLabel hint = new JLabel("Default password = your ID number");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(textGray);
        hint.setAlignmentX(CENTER_ALIGNMENT);

        // ── Assemble card ──
        card.add(logoText);
        card.add(Box.createVerticalStrut(2));
        card.add(subText);
        card.add(Box.createVerticalStrut(2));
        card.add(systemText);
        card.add(Box.createVerticalStrut(24));
        card.add(lblID);
        card.add(Box.createVerticalStrut(5));
        card.add(txtID);
        card.add(Box.createVerticalStrut(12));
        card.add(lblPw);
        card.add(Box.createVerticalStrut(5));
        card.add(txtPassword);
        card.add(Box.createVerticalStrut(6));
        card.add(lblError);
        card.add(Box.createVerticalStrut(14));
        card.add(btnLogin);
        card.add(Box.createVerticalStrut(8));
        card.add(btnRegister);  // ← NEW register button
        card.add(Box.createVerticalStrut(10));
        card.add(hint);

        add(card);
    }

    // ── Handle Login ──
    private void handleLogin() {
        String id       = txtID.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (id.isEmpty() || password.isEmpty()) {
            lblError.setText("Please enter your ID and password.");
            return;
        }

        User user = authService.login(id, password);

        if (user == null) {
            lblError.setText("Incorrect ID or password. Try again.");
            txtPassword.setText("");
            return;
        }

        // First login — force password change
        if (user.isFirstLogin()) {
            ChangePasswordDialog dialog = new ChangePasswordDialog(
                this, authService, user.getId()
            );
            dialog.setVisible(true);

            if (!dialog.isPasswordChanged()) {
                authService.logout();
                txtPassword.setText("");
                lblError.setText("Password change required to log in.");
                return;
            }
        }

        dispose();
        new MainFrame(authService);
    }

    // ── Open Student Registration ──
    private void openRegistration() {
        StudentRegistrationDialog reg = new StudentRegistrationDialog(
            this, authService, studentService
        );
        reg.setVisible(true);

        if (reg.isRegistered()) {
            lblError.setForeground(accentGreen);
            lblError.setText("Registration successful! You can now log in.");
        }
    }

    // ── UI Helpers ──
    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(textGray);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextField makeTextField() {
        JTextField tf = new JTextField();
        styleField(tf);
        return tf;
    }

    private void styleField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBackground(new Color(45, 45, 70));
        tf.setForeground(textWhite);
        tf.setCaretColor(textWhite);
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(8, 10, 8, 10)
        ));
        tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        tf.setAlignmentX(LEFT_ALIGNMENT);
    }
}