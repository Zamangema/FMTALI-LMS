package com.fmtali.lms.ui;

import com.fmtali.lms.model.Attendance;
import com.fmtali.lms.service.AttendanceService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

public class AttendancePanel extends JPanel {

    private final Color darkBg     = new Color(18, 18, 30);
    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);
    private final Color rowEven    = new Color(34, 34, 56);
    private final Color rowOdd     = new Color(40, 40, 65);

    private final AttendanceService attendanceService;
    private final String            viewerRole;

    private JTable            table;
    private DefaultTableModel tableModel;

    private JTextField        txtPersonID;
    private JTextField        txtPersonName;
    private JComboBox<String> cmbRole;
    private JTextField        txtLatitude;
    private JTextField        txtLongitude;
    private JLabel            lblLocationStatus;
    private JLabel            lblTodayCount;

    public AttendancePanel(AttendanceService service, String viewerRole) {
        this.attendanceService = service;
        this.viewerRole        = viewerRole;
        buildUI();
    }

    private void buildUI() {
        setLayout(new BorderLayout(10, 10));
        setBackground(darkBg);
        setBorder(new EmptyBorder(10, 12, 10, 12));

        add(buildSignInPanel(), BorderLayout.NORTH);
        add(buildTablePanel(),  BorderLayout.CENTER);

        refreshTable();
    }

    // ── Sign-in panel (top) ──
    // ✅ FIXED — split into 3 rows so nothing gets cut off
    private JPanel buildSignInPanel() {
        JPanel outer = new JPanel(new BorderLayout(0, 8));
        outer.setBackground(panelBg);
        outer.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentBlue, 1, true),
            new EmptyBorder(12, 16, 12, 16)
        ));

        // ── Row 1: Title ──
        JLabel title = new JLabel("Manual Attendance Entry");
        title.setFont(new Font("Segoe UI", Font.BOLD, 14));
        title.setForeground(accentGold);

        lblTodayCount = new JLabel("Today: 0 signed in");
        lblTodayCount.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblTodayCount.setForeground(textGray);
        lblTodayCount.setHorizontalAlignment(SwingConstants.RIGHT);

        JPanel titleRow = new JPanel(new BorderLayout());
        titleRow.setBackground(panelBg);
        titleRow.add(title,         BorderLayout.WEST);
        titleRow.add(lblTodayCount, BorderLayout.EAST);

        // ── Row 2: Input fields ──
        JPanel fieldsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        fieldsRow.setBackground(panelBg);

        txtPersonID   = smallField("Person ID / Student ID", 110);
        txtPersonName = smallField("Full Name",              150);
        txtLatitude   = smallField("Latitude",                90);
        txtLongitude  = smallField("Longitude",               90);

        // ✅ Pre-fill with correct FMTALI campus coordinates
        txtLatitude.setText("-26.0936");
        txtLongitude.setText("28.0064");

        // Role dropdown
        if (viewerRole.equals("ADMIN")) {
            cmbRole = new JComboBox<>(
                new String[]{"Student", "Facilitator"});
        } else {
            cmbRole = new JComboBox<>(new String[]{"Student"});
        }
        styleComboBox(cmbRole);

        fieldsRow.add(styledLabel("ID:"));
        fieldsRow.add(txtPersonID);
        fieldsRow.add(styledLabel("Name:"));
        fieldsRow.add(txtPersonName);
        fieldsRow.add(styledLabel("Role:"));
        fieldsRow.add(cmbRole);
        fieldsRow.add(styledLabel("Lat:"));
        fieldsRow.add(txtLatitude);
        fieldsRow.add(styledLabel("Lng:"));
        fieldsRow.add(txtLongitude);

        // ── Row 3: Buttons + location status ──
        JPanel buttonsRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        buttonsRow.setBackground(panelBg);

        JButton btnCheck   = makeButton("Check Location",
            new Color(90, 90, 140),  160);
        JButton btnSignIn  = makeButton("Sign In",
            new Color(72, 130, 255), 120);
        JButton btnSignOut = makeButton("Sign Out",
            new Color(80, 170, 110), 120);
        JButton btnRefresh = makeButton("Refresh Table",
            new Color(90, 90, 120),  130);

        btnCheck.addActionListener(e   -> checkLocation());
        btnSignIn.addActionListener(e  -> handleSignIn());
        btnSignOut.addActionListener(e -> handleSignOut());
        btnRefresh.addActionListener(e -> refreshTable());

        // Location status label next to buttons
        lblLocationStatus = new JLabel("  Click 'Check Location' first");
        lblLocationStatus.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lblLocationStatus.setForeground(textGray);

        buttonsRow.add(btnCheck);
        buttonsRow.add(btnSignIn);
        buttonsRow.add(btnSignOut);
        buttonsRow.add(btnRefresh);
        buttonsRow.add(lblLocationStatus);

        // ── Row 4: Info hint ──
        JLabel infoLbl = new JLabel(
            "  ⓘ Campus: Lat -26.0936, Lng 28.0064  "
            + "|  Must be within 500m to sign in.");
        infoLbl.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        infoLbl.setForeground(textGray);

        // Stack all rows using a BoxLayout inner panel
        JPanel allRows = new JPanel();
        allRows.setLayout(new BoxLayout(allRows, BoxLayout.Y_AXIS));
        allRows.setBackground(panelBg);
        allRows.add(titleRow);
        allRows.add(Box.createVerticalStrut(6));
        allRows.add(fieldsRow);
        allRows.add(buttonsRow);
        allRows.add(infoLbl);

        outer.add(allRows, BorderLayout.CENTER);
        return outer;
    }

    // ── Attendance table ──
    private JPanel buildTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(darkBg);

        String[] columns = {
            "ID", "Name", "Role", "Date",
            "Sign In", "Sign Out",
            "Location", "Distance", "Status"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        table = new JTable(tableModel);
        table.setBackground(rowEven);
        table.setForeground(textWhite);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setRowHeight(28);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setSelectionBackground(accentBlue);
        table.setSelectionForeground(Color.WHITE);

        table.getTableHeader().setBackground(new Color(22, 22, 40));
        table.getTableHeader().setForeground(accentGold);
        table.getTableHeader().setFont(
            new Font("Segoe UI", Font.BOLD, 13));
        table.getTableHeader().setReorderingAllowed(false);

        // Custom renderer — color Status and Location columns
        table.setDefaultRenderer(Object.class,
            new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(
                        JTable t, Object val, boolean sel,
                        boolean foc, int row, int col) {
                    super.getTableCellRendererComponent(
                        t, val, sel, foc, row, col);
                    setBorder(new EmptyBorder(0, 8, 0, 8));
                    if (!sel) {
                        setBackground(row % 2 == 0 ? rowEven : rowOdd);
                        setForeground(textWhite);

                        // Status column (col 8)
                        if (col == 8 && val != null) {
                            switch (val.toString()) {
                                case "Present":
                                    setForeground(new Color(80, 200, 120));
                                    break;
                                case "Late":
                                    setForeground(new Color(255, 196, 64));
                                    break;
                                case "Absent":
                                    setForeground(new Color(220, 80, 80));
                                    break;
                            }
                        }

                        // Location column (col 6)
                        if (col == 6 && val != null) {
                            if (val.toString().equals("On Campus")) {
                                setForeground(new Color(80, 200, 120));
                            } else {
                                setForeground(new Color(220, 80, 80));
                            }
                        }
                    }
                    return this;
                }
            });

        // Column widths
        int[] widths = {80, 140, 90, 100, 80, 80, 90, 80, 80};
        for (int i = 0; i < widths.length; i++)
            table.getColumnModel().getColumn(i)
                .setPreferredWidth(widths[i]);

        // Click row to fill sign-in fields
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int row = table.getSelectedRow();
                if (row >= 0) {
                    txtPersonID.setText(
                        tableModel.getValueAt(row, 0).toString());
                    txtPersonName.setText(
                        tableModel.getValueAt(row, 1).toString());
                }
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.getViewport().setBackground(rowEven);
        scroll.setBorder(
            BorderFactory.createLineBorder(accentBlue, 1));

        JLabel lbl = new JLabel("  Attendance Records");
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lbl.setForeground(accentBlue);
        lbl.setOpaque(true);
        lbl.setBackground(panelBg);
        lbl.setBorder(new EmptyBorder(8, 8, 8, 8));

        panel.add(lbl,    BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        return panel;
    }

    // ── Check Location ──
    private void checkLocation() {
        try {
            double lat = Double.parseDouble(
                txtLatitude.getText().trim());
            double lng = Double.parseDouble(
                txtLongitude.getText().trim());
            boolean onCampus = AttendanceService.isOnCampus(lat, lng);
            double  distance = AttendanceService
                .getDistanceFromCampus(lat, lng);

            if (onCampus) {
                lblLocationStatus.setText(
                    "  ✓ On Campus (" + (int) distance + "m)");
                lblLocationStatus.setForeground(
                    new Color(80, 200, 120));
            } else {
                lblLocationStatus.setText(
                    "  ✗ Off Campus (" + (int) distance + "m away)");
                lblLocationStatus.setForeground(
                    new Color(220, 80, 80));
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Enter valid coordinates.\n"
                + "Lat: -26.0936\nLng: 28.0064",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Sign In ──
    private void handleSignIn() {
        String id   = txtPersonID.getText().trim();
        String name = txtPersonName.getText().trim();
        String role = (String) cmbRole.getSelectedItem();

        if (id.isEmpty() || name.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Please enter Person ID and Name.",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double lat, lng;
        try {
            lat = Double.parseDouble(txtLatitude.getText().trim());
            lng = Double.parseDouble(txtLongitude.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                "Please enter valid GPS coordinates.\n"
                + "Lat: -26.0936   Lng: 28.0064",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Block if off campus
        if (!AttendanceService.isOnCampus(lat, lng)) {
            double dist = AttendanceService
                .getDistanceFromCampus(lat, lng);
            JOptionPane.showMessageDialog(this,
                "Sign-in denied!\n\n"
                + "You are " + (int) dist + "m from campus.\n"
                + "Must be within 500m of FMTALI to sign in.\n\n"
                + "Correct coordinates:\n"
                + "Lat: -26.0936   Lng: 28.0064",
                "Not On Campus", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Already signed in today?
        if (attendanceService.isAlreadySignedInToday(id)) {
            JOptionPane.showMessageDialog(this,
                id + " already signed in today.\n"
                + "Use Sign Out if leaving.",
                "Already Signed In",
                JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        Attendance record = attendanceService
            .signIn(id, name, role, lat, lng);

        if (record != null) {
            refreshTable();
            clearFields();
            JOptionPane.showMessageDialog(this,
                "✅ " + name + " signed in!\n"
                + "Status   : " + record.getStatus() + "\n"
                + "Location : " + record.getLocationStatus(),
                "Signed In",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                "Sign-in failed. Please try again.",
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ── Sign Out ──
    private void handleSignOut() {
        String id = txtPersonID.getText().trim();
        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Enter the Person ID to sign out.",
                "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = attendanceService.signOut(id);
        if (success) {
            refreshTable();
            JOptionPane.showMessageDialog(this,
                "✅ " + id + " signed out successfully!",
                "Signed Out",
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                id + " has not signed in today "
                + "or already signed out.",
                "Error", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ── Refresh table from Supabase ──
    public void refreshTable() {
        tableModel.setRowCount(0);

        List<Attendance> records = viewerRole.equals("ADMIN")
            ? attendanceService.getAllRecords()
            : attendanceService.getStudentRecords();

        for (Attendance a : records) {
            double dist = AttendanceService.getDistanceFromCampus(
                a.getLatitude(), a.getLongitude());
            tableModel.addRow(new Object[]{
                a.getPersonID(),
                a.getPersonName(),
                a.getRole(),
                a.getFormattedDate(),
                a.getFormattedSignIn(),
                a.getFormattedSignOut(),
                a.getLocationStatus(),
                (int) dist + "m",
                a.getStatus()
            });
        }

        long todayCount = attendanceService.getTodayRecords().size();
        lblTodayCount.setText("Today: " + todayCount + " signed in");
    }

    private void clearFields() {
        txtPersonID.setText("");
        txtPersonName.setText("");
        // ✅ Reset to correct campus coordinates
        txtLatitude.setText("-26.0936");
        txtLongitude.setText("28.0064");
        lblLocationStatus.setText("  Click 'Check Location' first");
        lblLocationStatus.setForeground(textGray);
    }

    // ── UI Helpers ──
    private JTextField smallField(String tooltip, int width) {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tf.setBackground(new Color(45, 45, 70));
        tf.setForeground(textWhite);
        tf.setCaretColor(textWhite);
        tf.setToolTipText(tooltip);
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(4, 6, 4, 6)
        ));
        tf.setPreferredSize(new Dimension(width, 30));
        return tf;
    }

    // ✅ FIXED — buttons now have fixed width so they always show
    private JButton makeButton(String text, Color bg, int width) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setPreferredSize(new Dimension(width, 32));
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(bg.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }

    private void styleComboBox(JComboBox<String> cb) {
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        cb.setBackground(new Color(45, 45, 70));
        cb.setForeground(textWhite);
        cb.setPreferredSize(new Dimension(110, 30));
    }

    private JLabel styledLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(textGray);
        return l;
    }
}