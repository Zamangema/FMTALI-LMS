package com.fmtali.lms.service;

import com.fmtali.lms.model.Attendance;
import com.fmtali.lms.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class AttendanceService {

    // ✅ FIXED — Correct FMTALI Randburg coordinates
    private static final double CAMPUS_LAT = -26.0936;
    private static final double CAMPUS_LNG =  28.0064;

    // ✅ FIXED — 500 metres as agreed
    private static final double ALLOWED_RADIUS_METRES = 500.0;

    // ── SIGN IN ──
    // Saves attendance record to Supabase
    // Returns null if already signed in today
    public Attendance signIn(String personID, String personName,
                             String role, double latitude,
                             double longitude) {

        // Check if already signed in today
        if (isAlreadySignedInToday(personID)) return null;

        String locationStatus = isOnCampus(latitude, longitude)
            ? "On Campus" : "Off Campus";

        String sql = "INSERT INTO attendance "
                   + "(person_id, person_name, role, sign_in_time, "
                   + "latitude, longitude, location_status, status, created_at) "
                   + "VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?, ?, ?, ?, CURRENT_TIMESTAMP)";

        // Determine status based on time (before 8:30 = Present, after = Late)
        LocalTime now    = LocalTime.now();
        String status    = now.isBefore(LocalTime.of(8, 30))
                         ? "Present" : "Late";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, personID);
            ps.setString(2, personName);
            ps.setString(3, role);
            ps.setDouble(4, latitude);
            ps.setDouble(5, longitude);
            ps.setString(6, locationStatus);
            ps.setString(7, status);
            ps.executeUpdate();
            System.out.println("✅ Attendance signed in: " + personID);

        } catch (SQLException e) {
            System.err.println("❌ Error signing in: " + e.getMessage());
            return null;
        }

        // Return the record object for display
        Attendance record = new Attendance(
            personID, personName, role,
            LocalDate.now(), now,
            latitude, longitude, locationStatus
        );
        return record;
    }

    // ── SIGN OUT ──
    // Updates sign_out_time in Supabase
    public boolean signOut(String personID) {
        // Check if signed in today
        if (!isAlreadySignedInToday(personID)) return false;

        // Check if already signed out
        String checkSql = "SELECT sign_out_time FROM attendance "
                        + "WHERE person_id = ? "
                        + "AND DATE(created_at) = CURRENT_DATE "
                        + "AND sign_out_time IS NOT NULL";

        String updateSql = "UPDATE attendance SET sign_out_time = CURRENT_TIMESTAMP "
                         + "WHERE person_id = ? "
                         + "AND DATE(created_at) = CURRENT_DATE "
                         + "AND sign_out_time IS NULL";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement check = conn.prepareStatement(checkSql)) {

            check.setString(1, personID);
            if (check.executeQuery().next()) {
                return false; // already signed out
            }

            try (PreparedStatement ps = conn.prepareStatement(updateSql)) {
                ps.setString(1, personID);
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    System.out.println("✅ Signed out: " + personID);
                    return true;
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error signing out: " + e.getMessage());
        }
        return false;
    }

    // ── GET ALL RECORDS (Admin sees everything) ──
    public List<Attendance> getAllRecords() {
        return fetchRecords("SELECT * FROM attendance ORDER BY created_at DESC");
    }

    // ── GET STUDENT RECORDS ONLY (Facilitator view) ──
    public List<Attendance> getStudentRecords() {
        return fetchRecords(
            "SELECT * FROM attendance WHERE role = 'Student' "
            + "ORDER BY created_at DESC");
    }

    // ── GET RECORDS FOR A SPECIFIC PERSON ──
    public List<Attendance> getRecordsForPerson(String personID) {
        List<Attendance> list = new ArrayList<>();
        String sql = "SELECT * FROM attendance WHERE person_id = ? "
                   + "ORDER BY created_at DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, personID);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) list.add(mapRow(rs));

        } catch (SQLException e) {
            System.err.println("❌ Error fetching records: " + e.getMessage());
        }
        return list;
    }

    // ── GET TODAY'S RECORDS ──
    public List<Attendance> getTodayRecords() {
        return fetchRecords(
            "SELECT * FROM attendance "
            + "WHERE DATE(created_at) = CURRENT_DATE "
            + "ORDER BY sign_in_time DESC");
    }

    // ── CHECK IF ALREADY SIGNED IN TODAY ──
    public boolean isAlreadySignedInToday(String personID) {
        String sql = "SELECT 1 FROM attendance "
                   + "WHERE person_id = ? "
                   + "AND DATE(created_at) = CURRENT_DATE";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, personID);
            return ps.executeQuery().next();

        } catch (SQLException e) {
            System.err.println("❌ Error checking sign in: " + e.getMessage());
        }
        return false;
    }

    // ── ATTENDANCE PERCENTAGE ──
    public double getAttendancePercentage(String personID,
                                          int totalClasses) {
        if (totalClasses == 0) return 0;
        String sql = "SELECT COUNT(*) FROM attendance "
                   + "WHERE person_id = ? "
                   + "AND status != 'Absent'";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, personID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                long attended = rs.getLong(1);
                return (attended * 100.0) / totalClasses;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error getting percentage: "
                + e.getMessage());
        }
        return 0;
    }

    // ── GEOFENCE CHECK ──
    // Uses Haversine formula to check if within 500m of FMTALI campus
    public static boolean isOnCampus(double lat, double lng) {
        double distanceMetres = haversine(
            CAMPUS_LAT, CAMPUS_LNG, lat, lng);
        return distanceMetres <= ALLOWED_RADIUS_METRES;
    }

    public static double getDistanceFromCampus(double lat, double lng) {
        return haversine(CAMPUS_LAT, CAMPUS_LNG, lat, lng);
    }

    // Haversine formula — distance in metres between two GPS points
    private static double haversine(double lat1, double lon1,
                                    double lat2, double lon2) {
        final double R = 6371000; // Earth radius in metres
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1))
                 * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    // ── Helper: fetch list of Attendance from SQL ──
    private List<Attendance> fetchRecords(String sql) {
        List<Attendance> list = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) list.add(mapRow(rs));

        } catch (SQLException e) {
            System.err.println("❌ Error fetching attendance: "
                + e.getMessage());
        }
        return list;
    }

    // ── Helper: map a ResultSet row to an Attendance object ──
    private Attendance mapRow(ResultSet rs) throws SQLException {
        // Parse sign_in_time
        Timestamp signInTs  = rs.getTimestamp("sign_in_time");
        Timestamp signOutTs = rs.getTimestamp("sign_out_time");
        Timestamp createdTs = rs.getTimestamp("created_at");

        LocalDate date = createdTs != null
            ? createdTs.toLocalDateTime().toLocalDate()
            : LocalDate.now();

        LocalTime signIn = signInTs != null
            ? signInTs.toLocalDateTime().toLocalTime()
            : LocalTime.now();

        Attendance a = new Attendance(
            rs.getString("person_id"),
            rs.getString("person_name"),
            rs.getString("role"),
            date,
            signIn,
            rs.getDouble("latitude"),
            rs.getDouble("longitude"),
            rs.getString("location_status")
        );

        // Set sign out time if exists
        if (signOutTs != null) {
            a.signOut(signOutTs.toLocalDateTime().toLocalTime());
        }

        return a;
    }
}