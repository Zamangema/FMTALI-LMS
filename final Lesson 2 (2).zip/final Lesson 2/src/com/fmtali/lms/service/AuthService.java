package com.fmtali.lms.service;

import com.fmtali.lms.model.Role;
import com.fmtali.lms.model.User;
import com.fmtali.lms.util.DatabaseConnection;
import com.fmtali.lms.util.PasswordUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// Handles login, logout, account creation, password changes
// Fully connected to Supabase PostgreSQL users table
public class AuthService {

    private User currentUser = null;

    public AuthService() {
        // Make sure default accounts exist in Supabase on startup
        seedDefaultAccountsIfNotExist();
    }

    // ── Creates default accounts in Supabase if they don't exist yet ──
    private void seedDefaultAccountsIfNotExist() {
        insertIfNotExists("admin",  "System Administrator", "admin",  Role.ADMIN,       false);
        insertIfNotExists("FAC001", "Facilitator One",      "FAC001", Role.FACILITATOR, true);
    }

    // Helper: inserts a user only if they don't already exist
    private void insertIfNotExists(String username, String fullName,
                                   String defaultPassword, Role role,
                                   boolean firstLogin) {
        String checkSql  = "SELECT 1 FROM users WHERE username = ?";
        String insertSql = "INSERT INTO users (user_id, username, full_name, password_hash, role, first_login) "
                         + "VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement check = conn.prepareStatement(checkSql)) {

            check.setString(1, username);
            ResultSet rs = check.executeQuery();

            if (!rs.next()) {
                try (PreparedStatement insert = conn.prepareStatement(insertSql)) {
                    insert.setString(1, username);
                    insert.setString(2, username);
                    insert.setString(3, fullName);
                    insert.setString(4, PasswordUtil.hash(defaultPassword));
                    insert.setString(5, role.name());
                    insert.setBoolean(6, firstLogin);
                    insert.executeUpdate();
                    System.out.println("✅ Default account created: " + username);
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Error seeding account: " + e.getMessage());
        }
    }

    // ── LOGIN ──
    // Checks Supabase users table
    // Returns User if correct, null if wrong credentials
    public User login(String username, String password) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username.trim());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password_hash");

                if (PasswordUtil.verify(password, storedHash)) {
                    currentUser = new User(
                        rs.getString("username"),
                        rs.getString("full_name"),
                        storedHash,
                        Role.valueOf(rs.getString("role"))
                    );
                    currentUser.setFirstLogin(rs.getBoolean("first_login"));
                    System.out.println("✅ Logged in: " + username
                        + " [" + rs.getString("role") + "]");
                    return currentUser;
                } else {
                    return null; // wrong password
                }
            }
        } catch (SQLException e) {
            System.err.println("❌ Login error: " + e.getMessage());
        }
        return null; // user not found
    }

    // ── LOGOUT ──
    public void logout() {
        System.out.println("👋 Logged out: "
            + (currentUser != null ? currentUser.getId() : "unknown"));
        currentUser = null;
    }

    // ── CHANGE PASSWORD ──
    // Updates password in Supabase and sets first_login = false
    // Used by any user to change their own password
    public boolean changePassword(String username, String newPassword) {
        String sql = "UPDATE users SET password_hash = ?, first_login = false "
                   + "WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, PasswordUtil.hash(newPassword));
            ps.setString(2, username);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                // Update in-memory session too
                if (currentUser != null
                        && currentUser.getId().equalsIgnoreCase(username)) {
                    currentUser.setPasswordHash(PasswordUtil.hash(newPassword));
                    currentUser.setFirstLogin(false);
                }
                System.out.println("✅ Password changed for: " + username);
                return true;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error changing password: " + e.getMessage());
        }
        return false;
    }

    // ── RESET PASSWORD ──
    // Called by Admin to reset any user's password back to their username
    // Sets first_login = true so they must change it on next login
    public void resetPassword(String username) {
        String sql = "UPDATE users SET password_hash = ?, first_login = true "
                   + "WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            // Reset password = their username/ID
            ps.setString(1, PasswordUtil.hash(username));
            ps.setString(2, username);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("✅ Password reset for: " + username);
            } else {
                System.out.println("⚠️ No account found: " + username);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error resetting password: " + e.getMessage());
        }
    }

    // ── CREATE NEW ACCOUNT ──
    // Called when Admin/Facilitator adds a student OR student self-registers
    // Default password = their student ID (username)
    // first_login = true so they are forced to change it on first login
    public boolean createAccount(String username, String fullName, Role role) {
        String checkSql  = "SELECT 1 FROM users WHERE username = ?";
        String insertSql = "INSERT INTO users (user_id, username, full_name, password_hash, role, first_login) "
                         + "VALUES (?, ?, ?, ?, ?, true)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement check = conn.prepareStatement(checkSql)) {

            check.setString(1, username);
            if (check.executeQuery().next()) {
                System.out.println("⚠️ Account already exists: " + username);
                return false;
            }

            try (PreparedStatement insert = conn.prepareStatement(insertSql)) {
                insert.setString(1, username); // user_id = same as username
                insert.setString(2, username); // username
                insert.setString(3, fullName);
                insert.setString(4, PasswordUtil.hash(username)); // default password = ID
                insert.setString(5, role.name());
                insert.executeUpdate();
                System.out.println("✅ Account created: " + username
                    + " [" + role.name() + "]");
                return true;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error creating account: " + e.getMessage());
        }
        return false;
    }

    // ── DELETE ACCOUNT ──
    // Called when Admin deletes a student or removes a user
    // Removes their login account from users table
    public void deleteAccount(String username) {
        String sql = "DELETE FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                System.out.println("✅ Account deleted: " + username);
            } else {
                System.out.println("⚠️ No account found to delete: "
                    + username);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error deleting account: " + e.getMessage());
        }
    }

    // ── CHECK IF FIRST LOGIN ──
    // Returns true if user hasn't changed their default password yet
    public boolean isFirstLogin(String username) {
        String sql = "SELECT first_login FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getBoolean("first_login");

        } catch (SQLException e) {
            System.err.println("❌ Error checking first login: "
                + e.getMessage());
        }
        return false;
    }

    // ── GET CURRENT LOGGED IN USER ──
    public User getCurrentUser() { return currentUser; }

    // ── FIND USER BY ID ──
    public User findById(String username) {
        String sql = "SELECT * FROM users WHERE username = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                User u = new User(
                    rs.getString("username"),
                    rs.getString("full_name"),
                    rs.getString("password_hash"),
                    Role.valueOf(rs.getString("role"))
                );
                u.setFirstLogin(rs.getBoolean("first_login"));
                return u;
            }
        } catch (SQLException e) {
            System.err.println("❌ Error finding user: " + e.getMessage());
        }
        return null;
    }

    // ── GET ALL USERS (Admin use) ──
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM users ORDER BY role, username";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                User u = new User(
                    rs.getString("username"),
                    rs.getString("full_name"),
                    rs.getString("password_hash"),
                    Role.valueOf(rs.getString("role"))
                );
                u.setFirstLogin(rs.getBoolean("first_login"));
                list.add(u);
            }
        } catch (SQLException e) {
            System.err.println("❌ Error fetching users: " + e.getMessage());
        }
        return list;
    }
}