package com.fmtali.lms.service;

import com.fmtali.lms.model.Student;
import com.fmtali.lms.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class StudentService {

    public void addStudent(Student s) {
        String sql = "INSERT INTO students (student_id, full_name, email, course_id, enroll_date, status, "
                   + "project1, project2, project3, test1, test2, test3, test4, test5, test6, test7, exam, exam_unlocked, created_at) "
                   + "VALUES (?, ?, ?, (SELECT id FROM courses WHERE course_name=? LIMIT 1), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getStudentID());
            ps.setString(2, s.getName());
            ps.setString(3, s.getEmail());
            ps.setString(4, s.getCourse());
            ps.setDate(5, Date.valueOf(s.getEnrollDate()));
            ps.setString(6, s.getStatus());
            ps.setDouble(7, s.getProject1());
            ps.setDouble(8, s.getProject2());
            ps.setDouble(9, s.getProject3());
            ps.setDouble(10, s.getTest1());
            ps.setDouble(11, s.getTest2());
            ps.setDouble(12, s.getTest3());
            ps.setDouble(13, s.getTest4());
            ps.setDouble(14, s.getTest5());
            ps.setDouble(15, s.getTest6());
            ps.setDouble(16, s.getTest7());
            ps.setDouble(17, s.getExam());
            ps.setBoolean(18, s.isExamUnlocked());
            ps.executeUpdate();
            System.out.println("Student saved: " + s.getStudentID());
        } catch (SQLException e) {
            System.err.println("Error saving student: " + e.getMessage());
        }
    }

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.*, c.course_name FROM students s "
                   + "LEFT JOIN courses c ON s.course_id = c.id";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                Student s = new Student(
                    rs.getString("student_id"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("course_name"),
                    rs.getDate("enroll_date").toLocalDate(),
                    rs.getString("status")
                );
                s.setProject1(rs.getDouble("project1"));
                s.setProject2(rs.getDouble("project2"));
                s.setProject3(rs.getDouble("project3"));
                s.setTest1(rs.getDouble("test1"));
                s.setTest2(rs.getDouble("test2"));
                s.setTest3(rs.getDouble("test3"));
                s.setTest4(rs.getDouble("test4"));
                s.setTest5(rs.getDouble("test5"));
                s.setTest6(rs.getDouble("test6"));
                s.setTest7(rs.getDouble("test7"));
                s.setExam(rs.getDouble("exam"));
                s.setExamUnlocked(rs.getBoolean("exam_unlocked"));
                list.add(s);
            }
        } catch (SQLException e) {
            System.err.println("Error fetching students: " + e.getMessage());
        }
        return list;
    }

    public Student getStudent(int index) {
        return getAllStudents().get(index);
    }

    public void updateStudent(int index, Student updated) {
        String sql = "UPDATE students SET full_name=?, email=?, status=?, "
                   + "project1=?, project2=?, project3=?, "
                   + "test1=?, test2=?, test3=?, test4=?, test5=?, test6=?, test7=?, "
                   + "exam=?, exam_unlocked=? WHERE student_id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, updated.getName());
            ps.setString(2, updated.getEmail());
            ps.setString(3, updated.getStatus());
            ps.setDouble(4, updated.getProject1());
            ps.setDouble(5, updated.getProject2());
            ps.setDouble(6, updated.getProject3());
            ps.setDouble(7, updated.getTest1());
            ps.setDouble(8, updated.getTest2());
            ps.setDouble(9, updated.getTest3());
            ps.setDouble(10, updated.getTest4());
            ps.setDouble(11, updated.getTest5());
            ps.setDouble(12, updated.getTest6());
            ps.setDouble(13, updated.getTest7());
            ps.setDouble(14, updated.getExam());
            ps.setBoolean(15, updated.isExamUnlocked());
            ps.setString(16, updated.getStudentID());
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error updating student: " + e.getMessage());
        }
    }

    public void deleteStudent(String studentId) {
        String sql = "DELETE FROM students WHERE student_id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, studentId);
            ps.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error deleting student: " + e.getMessage());
        }
    }

    public boolean studentIDExists(String id) {
        String sql = "SELECT 1 FROM students WHERE student_id=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, id);
            return ps.executeQuery().next();
        } catch (SQLException e) {
            System.err.println("Error checking ID: " + e.getMessage());
        }
        return false;
    }

    public int getTotalStudents() {
        String sql = "SELECT COUNT(*) FROM students";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            if (rs.next()) return rs.getInt(1);
        } catch (SQLException e) {
            System.err.println("Error counting students: " + e.getMessage());
        }
        return 0;
    }

    public long getCountByCourse(String course) {
        String sql = "SELECT COUNT(*) FROM students s JOIN courses c ON s.course_id=c.id WHERE c.course_name=?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, course);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return rs.getLong(1);
        } catch (SQLException e) {
            System.err.println("Error counting by course: " + e.getMessage());
        }
        return 0;
    }

    public boolean checkAndUnlockExam(Student s) {
        if (!s.isExamUnlocked() && s.qualifiesForExam()) {
            s.setExamUnlocked(true);
            String sql = "UPDATE students SET exam_unlocked=true WHERE student_id=?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, s.getStudentID());
                ps.executeUpdate();
            } catch (SQLException e) {
                System.err.println("Error unlocking exam: " + e.getMessage());
            }
            return true;
        }
        return false;
    }
}