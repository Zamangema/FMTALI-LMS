package com.fmtali.lms.model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class Attendance {

    // Who signed in
    private String personID;     // student ID or facilitator ID
    private String personName;
    private String role;         // "Student" or "Facilitator"

    // When
    private LocalDate date;
    private LocalTime signInTime;
    private LocalTime signOutTime; // null until they sign out

    // Where
    private double latitude;
    private double longitude;
    private String locationStatus; // "On Campus" or "Off Campus"

    // Attendance status
    private String status; // "Present", "Late", "Absent"

    private static final DateTimeFormatter TIME_FMT =
        DateTimeFormatter.ofPattern("HH:mm:ss");

    public Attendance(String personID, String personName, String role,
                      LocalDate date, LocalTime signInTime,
                      double latitude, double longitude,
                      String locationStatus) {
        this.personID       = personID;
        this.personName     = personName;
        this.role           = role;
        this.date           = date;
        this.signInTime     = signInTime;
        this.signOutTime    = null;
        this.latitude       = latitude;
        this.longitude      = longitude;
        this.locationStatus = locationStatus;

        // Auto-set status based on sign-in time
        // Before 08:30 = Present, after = Late
        this.status = signInTime.isBefore(LocalTime.of(8, 30))
            ? "Present" : "Late";
    }

    // Getters
    public String    getPersonID()       { return personID; }
    public String    getPersonName()     { return personName; }
    public String    getRole()           { return role; }
    public LocalDate getDate()           { return date; }
    public LocalTime getSignInTime()     { return signInTime; }
    public LocalTime getSignOutTime()    { return signOutTime; }
    public double    getLatitude()       { return latitude; }
    public double    getLongitude()      { return longitude; }
    public String    getLocationStatus() { return locationStatus; }
    public String    getStatus()         { return status; }

    // Called when student signs out
    public void signOut(LocalTime time) {
        this.signOutTime = time;
    }

    public boolean isSignedOut() {
        return signOutTime != null;
    }

    // Formatted times for table display
    public String getFormattedSignIn() {
        return signInTime.format(TIME_FMT);
    }

    public String getFormattedSignOut() {
        return signOutTime != null
            ? signOutTime.format(TIME_FMT) : "—";
    }

    public String getFormattedDate() {
        return date.format(
            DateTimeFormatter.ofPattern("dd MMM yyyy"));
    }
}