package com.fmtali.lms.model;

public enum Role {
    ADMIN,
    FACILITATOR,
    STUDENT
}