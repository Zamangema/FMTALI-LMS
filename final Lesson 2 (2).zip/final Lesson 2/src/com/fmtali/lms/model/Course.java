package com.fmtali.lms.model;

// This will become a database table later (Phase 2)
public class Course {

    public static final String[] COURSE_LIST = {
        "Java",
        "Power BI",
        "Azure-900",
        "AI-900"
    };

    private int    id;
    private String courseName;

    public Course(int id, String courseName) {
        this.id         = id;
        this.courseName = courseName;
    }

    public int    getId()         { return id; }
    public String getCourseName() { return courseName; }

    @Override
    public String toString() { return courseName; }
}