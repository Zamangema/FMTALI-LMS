package com.fmtali.lms.model;

public class User {

    private String id;          // SA ID number — also their username
    private String fullName;
    private String passwordHash; // never store plain text
    private Role   role;
    private boolean firstLogin;  // true = must change password

    public User(String id, String fullName,
                String passwordHash, Role role) {
        this.id           = id;
        this.fullName     = fullName;
        this.passwordHash = passwordHash;
        this.role         = role;
        this.firstLogin   = true; // always true when account first created
    }

    // Getters
    public String  getId()           { return id; }
    public String  getFullName()     { return fullName; }
    public String  getPasswordHash() { return passwordHash; }
    public Role    getRole()         { return role; }
    public boolean isFirstLogin()    { return firstLogin; }

    // Setters
    public void setPasswordHash(String hash) { this.passwordHash = hash; }
    public void setFirstLogin(boolean val)   { this.firstLogin   = val; }
    public void setFullName(String name)     { this.fullName     = name; }
}