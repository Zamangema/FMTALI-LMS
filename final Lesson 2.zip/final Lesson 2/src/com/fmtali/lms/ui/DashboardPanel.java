package com.fmtali.lms.ui;

import com.fmtali.lms.model.Course;
import com.fmtali.lms.service.StudentService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;

public class DashboardPanel extends JPanel {

    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);

    private final StudentService service;

    // Stat labels we'll update dynamically
    private JLabel lblTotalStudents;
    private JLabel[] lblCourseCounts;

    public DashboardPanel(StudentService service) {
        this.service = service;
        buildUI();
    }

    private void buildUI() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 10, 8));
        setBackground(new Color(18, 18, 30));

        // Total students card
        lblTotalStudents = new JLabel("0");
        add(buildCard("Total Students", lblTotalStudents, accentBlue));

        // One card per course
        lblCourseCounts = new JLabel[Course.COURSE_LIST.length];
        for (int i = 0; i < Course.COURSE_LIST.length; i++) {
            lblCourseCounts[i] = new JLabel("0");
            add(buildCard(Course.COURSE_LIST[i], lblCourseCounts[i], accentGold));
        }
    }

    private JPanel buildCard(String title, JLabel valueLabel, Color accent) {
        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(panelBg);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accent, 1, true),
            new EmptyBorder(10, 16, 10, 16)
        ));
        card.setPreferredSize(new Dimension(130, 70));

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        titleLbl.setForeground(textGray);
        titleLbl.setAlignmentX(CENTER_ALIGNMENT);

        valueLabel.setFont(new Font("Segoe UI", Font.BOLD, 28));
        valueLabel.setForeground(accent);
        valueLabel.setAlignmentX(CENTER_ALIGNMENT);

        card.add(titleLbl);
        card.add(valueLabel);
        return card;
    }

    // Call this whenever a student is added, updated, or deleted
    public void refresh() {
        lblTotalStudents.setText(String.valueOf(service.getTotalStudents()));
        for (int i = 0; i < Course.COURSE_LIST.length; i++) {
            lblCourseCounts[i].setText(
                String.valueOf(service.getCountByCourse(Course.COURSE_LIST[i]))
            );
        }
    }
}