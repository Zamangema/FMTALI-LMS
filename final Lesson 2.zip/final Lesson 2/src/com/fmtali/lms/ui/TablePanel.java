package com.fmtali.lms.ui;

import com.fmtali.lms.model.Student;
import com.fmtali.lms.service.StudentService;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;

public class TablePanel extends JPanel {

    private final Color darkBg     = new Color(18, 18, 30);
    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);
    private final Color rowEven    = new Color(34, 34, 56);
    private final Color rowOdd     = new Color(40, 40, 65);

    private JTable            studentTable;
    private DefaultTableModel tableModel;
    private TableRowSorter<DefaultTableModel> sorter;
    private JTextField        txtSearch;

    private FormPanel      formPanel;
    private DashboardPanel dashboardPanel;

    private final StudentService service;

    // Column indexes
    private static final int COL_STATUS = 4;
    private static final int COL_GRADE  = 7;

    public TablePanel(StudentService service) {
        this.service = service;
        buildUI();
    }

    public void setFormPanel(FormPanel fp)           { this.formPanel      = fp; }
    public void setDashboardPanel(DashboardPanel dp) { this.dashboardPanel = dp; }

    private void buildUI() {
        setLayout(new BorderLayout(0, 8));
        setBackground(darkBg);
        setBorder(new EmptyBorder(10, 6, 10, 12));

        // ── Top bar ──
        JPanel topBar = new JPanel(new BorderLayout(10, 0));
        topBar.setBackground(panelBg);
        topBar.setBorder(new EmptyBorder(8, 8, 8, 8));

        JLabel tableTitle = new JLabel("  All Student Records");
        tableTitle.setFont(new Font("Segoe UI", Font.BOLD, 14));
        tableTitle.setForeground(accentBlue);

        txtSearch = new JTextField();
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        txtSearch.setBackground(new Color(45, 45, 70));
        txtSearch.setForeground(textWhite);
        txtSearch.setCaretColor(textWhite);
        txtSearch.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(4, 8, 4, 8)
        ));
        txtSearch.setToolTipText("Search by name, ID, email or course...");
        txtSearch.setText("Search students...");
        txtSearch.setForeground(textGray);

        txtSearch.addFocusListener(new FocusAdapter() {
            public void focusGained(FocusEvent e) {
                if (txtSearch.getText().equals("Search students...")) {
                    txtSearch.setText("");
                    txtSearch.setForeground(textWhite);
                }
            }
            public void focusLost(FocusEvent e) {
                if (txtSearch.getText().isEmpty()) {
                    txtSearch.setText("Search students...");
                    txtSearch.setForeground(textGray);
                }
            }
        });

        txtSearch.addKeyListener(new KeyAdapter() {
            public void keyReleased(KeyEvent e) {
                String text = txtSearch.getText().trim();
                if (text.equals("Search students...") || text.isEmpty()) {
                    sorter.setRowFilter(null);
                } else {
                    sorter.setRowFilter(
                        RowFilter.regexFilter("(?i)" + text));
                }
            }
        });

        JLabel searchIcon = new JLabel("  Search: ");
        searchIcon.setForeground(textGray);
        searchIcon.setFont(new Font("Segoe UI", Font.PLAIN, 12));

        topBar.add(tableTitle, BorderLayout.WEST);
        topBar.add(searchIcon, BorderLayout.CENTER);
        topBar.add(txtSearch,  BorderLayout.EAST);

        // ── Table columns ──
        String[] columns = {
            "ID", "Name", "Email", "Course",
            "Status",
            "Enrolled On", "Duration",
            "Grade", "Final Mark"
        };

        tableModel = new DefaultTableModel(columns, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };

        studentTable = new JTable(tableModel);
        studentTable.setBackground(rowEven);
        studentTable.setForeground(textWhite);
        studentTable.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        studentTable.setRowHeight(28);
        studentTable.setShowGrid(false);
        studentTable.setIntercellSpacing(new Dimension(0, 1));
        studentTable.setSelectionBackground(accentBlue);
        studentTable.setSelectionForeground(Color.WHITE);

        studentTable.getTableHeader().setBackground(new Color(22, 22, 40));
        studentTable.getTableHeader().setForeground(accentGold);
        studentTable.getTableHeader().setFont(
            new Font("Segoe UI", Font.BOLD, 13));
        studentTable.getTableHeader().setReorderingAllowed(false);

        // Custom renderer — color Status and Grade columns
        studentTable.setDefaultRenderer(Object.class,
            new DefaultTableCellRenderer() {
                public Component getTableCellRendererComponent(
                        JTable t, Object val, boolean sel,
                        boolean foc, int row, int col) {
                    super.getTableCellRendererComponent(
                        t, val, sel, foc, row, col);
                    setBorder(new EmptyBorder(0, 8, 0, 8));
                    if (!sel) {
                        setBackground(row % 2 == 0 ? rowEven : rowOdd);
                        setForeground(textWhite);

                        // Color Status column
                        if (col == COL_STATUS && val != null) {
                            switch (val.toString()) {
                                case "Active":
                                    setForeground(new Color(80, 200, 120));
                                    break;
                                case "Suspended":
                                    setForeground(new Color(220, 80, 80));
                                    break;
                                case "Graduated":
                                    setForeground(new Color(100, 180, 255));
                                    break;
                                case "Dropped":
                                    setForeground(new Color(255, 140, 60));
                                    break;
                            }
                        }

                        // Color Grade column
                        if (col == COL_GRADE && val != null) {
                            switch (val.toString()) {
                                case "A":
                                    setForeground(new Color(80, 200, 120));
                                    break;
                                case "B":
                                    setForeground(new Color(100, 180, 255));
                                    break;
                                case "C":
                                    setForeground(new Color(255, 196, 64));
                                    break;
                                case "D":
                                    setForeground(new Color(255, 140, 60));
                                    break;
                                case "F":
                                    setForeground(new Color(220, 80, 80));
                                    break;
                            }
                        }
                    }
                    return this;
                }
            });

        sorter = new TableRowSorter<>(tableModel);
        studentTable.setRowSorter(sorter);

        // Column widths
        int[] widths = {65, 120, 150, 100, 85, 110, 110, 55, 80};
        for (int i = 0; i < widths.length; i++)
            studentTable.getColumnModel().getColumn(i)
                .setPreferredWidth(widths[i]);

        // Row click → fill form
        studentTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                int viewRow = studentTable.getSelectedRow();
                if (viewRow >= 0 && formPanel != null) {
                    int modelRow = studentTable
                        .convertRowIndexToModel(viewRow);
                    Student s = service.getStudent(modelRow);
                    formPanel.fillFromStudent(s, modelRow);
                }
            }
        });

        JScrollPane scroll = new JScrollPane(studentTable);
        scroll.getViewport().setBackground(rowEven);
        scroll.setBorder(BorderFactory.createLineBorder(accentBlue, 1));

        add(topBar, BorderLayout.NORTH);
        add(scroll,  BorderLayout.CENTER);
    }

    public void addRow(Student s) {
        tableModel.addRow(new Object[]{
            s.getStudentID(),
            s.getName(),
            s.getEmail(),
            s.getCourse(),
            s.getStatus(),
            s.getFormattedEnrollDate(),
            s.getEnrollmentDuration(),
            s.getGrade(),
            s.isExamUnlocked()
                ? String.format("%.1f", s.getFinalMark()) : "—"
        });
    }

    public void updateRow(int modelRow, Student s) {
        tableModel.setValueAt(s.getStudentID(),           modelRow, 0);
        tableModel.setValueAt(s.getName(),                modelRow, 1);
        tableModel.setValueAt(s.getEmail(),               modelRow, 2);
        tableModel.setValueAt(s.getCourse(),              modelRow, 3);
        tableModel.setValueAt(s.getStatus(),              modelRow, 4);
        tableModel.setValueAt(s.getFormattedEnrollDate(), modelRow, 5);
        tableModel.setValueAt(s.getEnrollmentDuration(),  modelRow, 6);
        tableModel.setValueAt(s.getGrade(),               modelRow, 7);
        tableModel.setValueAt(s.isExamUnlocked()
            ? String.format("%.1f", s.getFinalMark()) : "—",
            modelRow, 8);
    }

    public void deleteRow(int modelRow)  { tableModel.removeRow(modelRow); }
    public void clearSelection()         { studentTable.clearSelection(); }
    public void refreshDashboard() {
        if (dashboardPanel != null) dashboardPanel.refresh();
    }
}