package com.fmtali.lms.ui;

import com.fmtali.lms.model.Course;
import com.fmtali.lms.model.Student;
import com.fmtali.lms.service.StudentService;
import com.fmtali.lms.util.ValidationUtil;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;

public class FormPanel extends JPanel {

    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);

    // Basic fields
    private JTextField        txtStudentID;
    private JTextField        txtName;
    private JTextField        txtEmail;
    private JComboBox<String> cmbCourse;
    private JTextField        txtEnrollDate;
    private JLabel            lblDuration;

    // Status
    private JComboBox<String> cmbStatus;

    // Project fields (3)
    private JTextField txtP1, txtP2, txtP3;
    private JLabel     lblProjectMark;

    // Test fields (up to 7, show/hide based on course)
    private JTextField[] testFields = new JTextField[7];
    private JLabel[]     testLabels = new JLabel[7];
    private JLabel       lblTestMark;

    // Combined + exam
    private JLabel     lblCombined;
    private JLabel     lblExamStatus;
    private JTextField txtExam;
    private JLabel     lblFinalMark;
    private JLabel     lblGrade;

    // Buttons
    private JButton btnAdd, btnUpdate, btnDelete, btnClear;

    private final StudentService service;
    private final TablePanel     tablePanel;
    private int selectedRow = -1;

    public FormPanel(StudentService service, TablePanel tablePanel) {
        this.service    = service;
        this.tablePanel = tablePanel;
        buildUI();
    }

    private void buildUI() {
        setLayout(new BorderLayout());
        setPreferredSize(new Dimension(310, 0));
        setBackground(new Color(18, 18, 30));
        setBorder(new EmptyBorder(10, 12, 10, 6));

        JPanel form = new JPanel();
        form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
        form.setBackground(panelBg);
        form.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentBlue, 1, true),
            new EmptyBorder(16, 16, 16, 16)
        ));

        // ── Student Details ──
        form.add(sectionLabel("Student Details"));
        form.add(Box.createVerticalStrut(8));

        form.add(fieldLabel("Student ID"));
        txtStudentID = makeTextField();
        form.add(txtStudentID);
        form.add(Box.createVerticalStrut(6));

        form.add(fieldLabel("Full Name"));
        txtName = makeTextField();
        form.add(txtName);
        form.add(Box.createVerticalStrut(6));

        form.add(fieldLabel("Email Address"));
        txtEmail = makeTextField();
        form.add(txtEmail);
        form.add(Box.createVerticalStrut(6));

        form.add(fieldLabel("Course / Programme"));
        cmbCourse = makeComboBox(Course.COURSE_LIST);
        cmbCourse.addActionListener(e -> onCourseChanged());
        form.add(cmbCourse);
        form.add(Box.createVerticalStrut(6));

        form.add(fieldLabel("Enrollment Date (YYYY-MM-DD)"));
        txtEnrollDate = makeTextField();
        form.add(txtEnrollDate);
        form.add(Box.createVerticalStrut(6));

        lblDuration = new JLabel(" ");
        lblDuration.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblDuration.setForeground(accentGold);
        lblDuration.setAlignmentX(LEFT_ALIGNMENT);
        form.add(lblDuration);
        form.add(Box.createVerticalStrut(12));

        // ── Status ──
        form.add(sectionLabel("Student Status"));
        form.add(Box.createVerticalStrut(4));
        form.add(fieldLabel("Suspended / Dropped only — others are automatic"));
        form.add(Box.createVerticalStrut(4));
        cmbStatus = makeComboBox(new String[]{
            "Active", "Suspended", "Dropped"
        });
        form.add(cmbStatus);
        form.add(Box.createVerticalStrut(12));

        // ── Projects ──
        form.add(sectionLabel("Projects (Best 2 of 3 averaged)"));
        form.add(Box.createVerticalStrut(6));

        form.add(fieldLabel("Project 1 (out of 100)"));
        txtP1 = makeMarkField();
        form.add(txtP1);
        form.add(Box.createVerticalStrut(4));

        form.add(fieldLabel("Project 2 (out of 100)"));
        txtP2 = makeMarkField();
        form.add(txtP2);
        form.add(Box.createVerticalStrut(4));

        form.add(fieldLabel("Project 3 (out of 100)"));
        txtP3 = makeMarkField();
        form.add(txtP3);
        form.add(Box.createVerticalStrut(4));

        lblProjectMark = resultLabel("Project Mark: —");
        form.add(lblProjectMark);
        form.add(Box.createVerticalStrut(12));

        // ── Tests (7 slots, shown based on course) ──
        form.add(sectionLabel("Tests"));
        form.add(Box.createVerticalStrut(6));

        for (int i = 0; i < 7; i++) {
            final int num = i + 1;
            testLabels[i] = fieldLabel("Test " + num + " (out of 100)");
            testFields[i] = makeMarkField();
            form.add(testLabels[i]);
            form.add(testFields[i]);
            form.add(Box.createVerticalStrut(4));
        }

        lblTestMark = resultLabel("Test Mark: —");
        form.add(lblTestMark);
        form.add(Box.createVerticalStrut(12));

        // ── Combined + Exam ──
        form.add(sectionLabel("Exam"));
        form.add(Box.createVerticalStrut(6));

        lblCombined = resultLabel("Combined (Project+Test): —");
        form.add(lblCombined);
        form.add(Box.createVerticalStrut(4));

        lblExamStatus = new JLabel("— Enter project & test marks first");
        lblExamStatus.setFont(new Font("Segoe UI", Font.BOLD, 11));
        lblExamStatus.setForeground(textGray);
        lblExamStatus.setAlignmentX(LEFT_ALIGNMENT);
        form.add(lblExamStatus);
        form.add(Box.createVerticalStrut(4));

        form.add(fieldLabel("Exam Mark (out of 100)"));
        txtExam = makeMarkField();
        txtExam.setEnabled(false); // locked until qualified
        form.add(txtExam);
        form.add(Box.createVerticalStrut(8));

        // Final mark + grade
        JPanel markRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        markRow.setBackground(panelBg);
        markRow.setAlignmentX(LEFT_ALIGNMENT);
        markRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 24));

        JLabel fp = new JLabel("Final: ");
        fp.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        fp.setForeground(textGray);

        lblFinalMark = new JLabel("—");
        lblFinalMark.setFont(new Font("Segoe UI", Font.BOLD, 13));
        lblFinalMark.setForeground(textWhite);

        JLabel gp = new JLabel("   Grade: ");
        gp.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        gp.setForeground(textGray);

        lblGrade = new JLabel("—");
        lblGrade.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblGrade.setForeground(textGray);

        markRow.add(fp);
        markRow.add(lblFinalMark);
        markRow.add(gp);
        markRow.add(lblGrade);
        form.add(markRow);
        form.add(Box.createVerticalStrut(16));

        // ── Buttons ──
        btnAdd    = makeButton("Add Student",   accentBlue);
        btnUpdate = makeButton("Update Record", new Color(80, 170, 110));
        btnDelete = makeButton("Delete Record", new Color(210, 70, 70));
        btnClear  = makeButton("Clear Fields",  new Color(90, 90, 120));

        btnAdd.addActionListener(e    -> handleAdd());
        btnUpdate.addActionListener(e -> handleUpdate());
        btnDelete.addActionListener(e -> handleDelete());
        btnClear.addActionListener(e  -> clearFields());

        form.add(btnAdd);    form.add(Box.createVerticalStrut(8));
        form.add(btnUpdate); form.add(Box.createVerticalStrut(8));
        form.add(btnDelete); form.add(Box.createVerticalStrut(8));
        form.add(btnClear);

        // Add key listeners to all mark fields
        KeyAdapter calc = new KeyAdapter() {
            public void keyReleased(KeyEvent e) { recalculate(); }
        };
        txtP1.addKeyListener(calc);
        txtP2.addKeyListener(calc);
        txtP3.addKeyListener(calc);
        for (JTextField tf : testFields) tf.addKeyListener(calc);
        txtExam.addKeyListener(calc);

        JScrollPane scroll = new JScrollPane(form);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(panelBg);
        scroll.setHorizontalScrollBarPolicy(
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        add(scroll, BorderLayout.CENTER);

        // Set initial course
        onCourseChanged();
    }

    // Show/hide test fields based on course
    private void onCourseChanged() {
        String course = (String) cmbCourse.getSelectedItem();
        int count = course.equalsIgnoreCase("Java") ? 7 : 5;
        for (int i = 0; i < 7; i++) {
            boolean show = i < count;
            testLabels[i].setVisible(show);
            testFields[i].setVisible(show);
        }
        recalculate();
        revalidate();
        repaint();
    }

    // Recalculate everything live
    private void recalculate() {
        try {
            // Project mark — best 2 of 3
            double p1 = parse(txtP1), p2 = parse(txtP2), p3 = parse(txtP3);
            double[] projs = {p1, p2, p3};
            java.util.Arrays.sort(projs);
            double projectMark = (projs[1] + projs[2]) / 2.0;
            lblProjectMark.setText(String.format(
                "Project Mark: %.1f%%", projectMark));

            // Test mark
            String course = (String) cmbCourse.getSelectedItem();
            double testMark;
            if (course.equalsIgnoreCase("Java")) {
                double[] t = new double[7];
                for (int i = 0; i < 7; i++)
                    t[i] = parse(testFields[i]);
                java.util.Arrays.sort(t);
                testMark = (t[2]+t[3]+t[4]+t[5]+t[6]) / 5.0;
            } else {
                double[] t = new double[5];
                for (int i = 0; i < 5; i++)
                    t[i] = parse(testFields[i]);
                java.util.Arrays.sort(t);
                testMark = (t[2]+t[3]+t[4]) / 3.0;
            }
            lblTestMark.setText(String.format(
                "Test Mark: %.1f%%", testMark));

            // Combined
            double combined = (projectMark + testMark) / 2.0;
            lblCombined.setText(String.format(
                "Combined (Project+Test): %.1f%%", combined));

            // Exam unlock check
            if (combined >= 50.0) {
                txtExam.setEnabled(true);
                lblExamStatus.setText(
                    "✓ Qualifies to write exam");
                lblExamStatus.setForeground(
                    new Color(80, 200, 120));
            } else {
                txtExam.setEnabled(false);
                txtExam.setText("0");
                double needed = 50.0 - combined;
                lblExamStatus.setText(String.format(
                    "✗ Needs %.1f%% more to qualify", needed));
                lblExamStatus.setForeground(
                    new Color(220, 80, 80));
            }

            // Final mark + grade (only if exam unlocked)
            if (txtExam.isEnabled()) {
                double examMark = parse(txtExam);
                double finalMark = (projectMark * 0.20)
                                 + (testMark    * 0.30)
                                 + (examMark    * 0.50);
                lblFinalMark.setText(String.format("%.1f", finalMark));

                String grade; Color gc;
                if (finalMark >= 80) { grade="A"; gc=new Color(80,200,120); }
                else if (finalMark >= 70) { grade="B"; gc=new Color(100,180,255); }
                else if (finalMark >= 60) { grade="C"; gc=new Color(255,196,64); }
                else if (finalMark >= 50) { grade="D"; gc=new Color(255,140,60); }
                else                      { grade="F"; gc=new Color(220,80,80); }

                lblGrade.setText(grade);
                lblGrade.setForeground(gc);

                // Graduation hint
                double passmark = course.equalsIgnoreCase("Java")
                    ? 65.0 : 70.0;
                if (finalMark >= passmark) {
                    lblDuration.setText("Will graduate ✓");
                    lblDuration.setForeground(new Color(80,200,120));
                } else {
                    lblDuration.setText(String.format(
                        "Needs %.1f%% more to graduate",
                        passmark - finalMark));
                    lblDuration.setForeground(new Color(255,140,60));
                }
            } else {
                lblFinalMark.setText("—");
                lblGrade.setText("—");
                lblGrade.setForeground(textGray);
            }

        } catch (Exception ignored) {}
    }

    // Fill form from table row
    public void fillFromStudent(Student s, int row) {
        selectedRow = row;
        txtStudentID.setText(s.getStudentID());
        txtName.setText(s.getName());
        txtEmail.setText(s.getEmail());
        cmbCourse.setSelectedItem(s.getCourse());
        txtEnrollDate.setText(s.getEnrollDate().toString());
        lblDuration.setText(s.getEnrollmentDuration());
        String st = s.getStatus();
        cmbStatus.setSelectedItem(
            (st.equals("Graduated") || st.equals("Active"))
                ? "Active" : st);
        txtP1.setText(fmt(s.getProject1()));
        txtP2.setText(fmt(s.getProject2()));
        txtP3.setText(fmt(s.getProject3()));
        testFields[0].setText(fmt(s.getTest1()));
        testFields[1].setText(fmt(s.getTest2()));
        testFields[2].setText(fmt(s.getTest3()));
        testFields[3].setText(fmt(s.getTest4()));
        testFields[4].setText(fmt(s.getTest5()));
        testFields[5].setText(fmt(s.getTest6()));
        testFields[6].setText(fmt(s.getTest7()));
        txtExam.setText(fmt(s.getExam()));
        onCourseChanged();
        recalculate();
    }

    private void handleAdd() {
        if (!validateForm()) return;
        String id      = txtStudentID.getText().trim();
        String name    = txtName.getText().trim();
        String email   = txtEmail.getText().trim();
        String course  = (String) cmbCourse.getSelectedItem();
        String dateStr = txtEnrollDate.getText().trim();

        if (service.studentIDExists(id)) {
            ValidationUtil.showError(this, "Student ID already exists!");
            return;
        }
        LocalDate date = ValidationUtil.parseDate(dateStr, this);
        if (date == null) return;

        Student s = new Student(id, name, email, course, date, "Active");
        applyMarks(s);
        service.checkAndUnlockExam(s);
        s.setStatus(s.computeStatus());

        service.addStudent(s);
        tablePanel.addRow(s);
        tablePanel.refreshDashboard();
        clearFields();
        JOptionPane.showMessageDialog(this,
            "Student added successfully!",
            "Success", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleUpdate() {
        if (selectedRow < 0) {
            ValidationUtil.showError(this,
                "Select a student first."); return;
        }
        if (!validateForm()) return;
        LocalDate date = ValidationUtil.parseDate(
            txtEnrollDate.getText().trim(), this);
        if (date == null) return;

        String selectedStatus = (String) cmbStatus.getSelectedItem();
        Student updated = new Student(
            txtStudentID.getText().trim(),
            txtName.getText().trim(),
            txtEmail.getText().trim(),
            (String) cmbCourse.getSelectedItem(),
            date, selectedStatus
        );
        applyMarks(updated);
        service.checkAndUnlockExam(updated);
        updated.setStatus(updated.computeStatus());

        service.updateStudent(selectedRow, updated);
        tablePanel.updateRow(selectedRow, updated);
        tablePanel.refreshDashboard();
        clearFields();
        JOptionPane.showMessageDialog(this, "Record updated!",
            "Updated", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleDelete() {
        if (selectedRow < 0) {
            ValidationUtil.showError(this,
                "Select a student first."); return;
        }
        int ok = JOptionPane.showConfirmDialog(this,
            "Delete this student record?", "Confirm",
            JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) {
            service.deleteStudent(selectedRow);
            tablePanel.deleteRow(selectedRow);
            tablePanel.refreshDashboard();
            clearFields();
        }
    }

    // Copy all mark fields into the Student object
    private void applyMarks(Student s) {
        s.setProject1(parse(txtP1));
        s.setProject2(parse(txtP2));
        s.setProject3(parse(txtP3));
        s.setTest1(parse(testFields[0]));
        s.setTest2(parse(testFields[1]));
        s.setTest3(parse(testFields[2]));
        s.setTest4(parse(testFields[3]));
        s.setTest5(parse(testFields[4]));
        s.setTest6(parse(testFields[5]));
        s.setTest7(parse(testFields[6]));
        if (txtExam.isEnabled())
            s.setExam(parse(txtExam));
    }

    public void clearFields() {
        txtStudentID.setText("");
        txtName.setText("");
        txtEmail.setText("");
        cmbCourse.setSelectedIndex(0);
        txtEnrollDate.setText("");
        lblDuration.setText(" ");
        cmbStatus.setSelectedIndex(0);
        txtP1.setText("0"); txtP2.setText("0"); txtP3.setText("0");
        for (JTextField tf : testFields) tf.setText("0");
        txtExam.setText("0");
        txtExam.setEnabled(false);
        lblProjectMark.setText("Project Mark: —");
        lblTestMark.setText("Test Mark: —");
        lblCombined.setText("Combined (Project+Test): —");
        lblExamStatus.setText("— Enter project & test marks first");
        lblExamStatus.setForeground(textGray);
        lblFinalMark.setText("—");
        lblGrade.setText("—");
        lblGrade.setForeground(textGray);
        selectedRow = -1;
        tablePanel.clearSelection();
    }

    // Role restrictions
    public void setRole(String role) {
        switch (role) {
            case "STUDENT":
                btnAdd.setVisible(false);
                btnDelete.setVisible(false);
                btnUpdate.setVisible(false);
                txtStudentID.setEditable(false);
                txtName.setEditable(false);
                txtEmail.setEditable(false);
                cmbCourse.setEnabled(false);
                txtEnrollDate.setEditable(false);
                cmbStatus.setEnabled(false);
                txtP1.setEditable(false);
                txtP2.setEditable(false);
                txtP3.setEditable(false);
                for (JTextField tf : testFields) tf.setEditable(false);
                txtExam.setEditable(false);
                break;
            case "FACILITATOR":
                btnAdd.setVisible(false);
                btnDelete.setVisible(false);
                txtStudentID.setEditable(false);
                txtName.setEditable(false);
                txtEmail.setEditable(false);
                cmbCourse.setEnabled(false);
                txtEnrollDate.setEditable(false);
                cmbStatus.removeAllItems();
                cmbStatus.addItem("Suspended");
                cmbStatus.addItem("Dropped");
                break;
            case "ADMIN":
            default:
                break;
        }
    }

    private boolean validateForm() {
        if (ValidationUtil.isNullOrEmpty(txtStudentID.getText())) {
            ValidationUtil.showError(this, "Student ID cannot be empty.");
            return false;
        }
        if (ValidationUtil.isNullOrEmpty(txtName.getText())) {
            ValidationUtil.showError(this, "Name cannot be empty.");
            return false;
        }
        if (!ValidationUtil.isValidEmail(txtEmail.getText())) {
            ValidationUtil.showError(this, "Please enter a valid email.");
            return false;
        }
        if (ValidationUtil.isNullOrEmpty(txtEnrollDate.getText())) {
            ValidationUtil.showError(this, "Enrollment date cannot be empty.");
            return false;
        }
        return true;
    }

    // ── Helpers ──
    private double parse(JTextField tf) {
        try {
            double v = Double.parseDouble(tf.getText().trim());
            return Math.max(0, Math.min(100, v));
        } catch (NumberFormatException e) { return 0; }
    }

    private String fmt(double v) {
        return v == 0 ? "0" : String.valueOf(v);
    }

    private JLabel sectionLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 13));
        l.setForeground(accentGold);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setForeground(textGray);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JLabel resultLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.BOLD, 12));
        l.setForeground(accentBlue);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextField makeTextField() {
        JTextField tf = new JTextField();
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBackground(new Color(45, 45, 70));
        tf.setForeground(textWhite);
        tf.setCaretColor(textWhite);
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(5, 8, 5, 8)
        ));
        tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        tf.setAlignmentX(LEFT_ALIGNMENT);
        return tf;
    }

    private JTextField makeMarkField() {
        JTextField tf = makeTextField();
        tf.setText("0");
        return tf;
    }

    private JComboBox<String> makeComboBox(String[] items) {
        JComboBox<String> cb = new JComboBox<>(items);
        cb.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        cb.setBackground(new Color(45, 45, 70));
        cb.setForeground(textWhite);
        cb.setMaximumSize(new Dimension(Integer.MAX_VALUE, 34));
        cb.setAlignmentX(LEFT_ALIGNMENT);
        return cb;
    }

    private JButton makeButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        btn.setAlignmentX(LEFT_ALIGNMENT);
        btn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btn.setBackground(bg.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btn.setBackground(bg);
            }
        });
        return btn;
    }
}