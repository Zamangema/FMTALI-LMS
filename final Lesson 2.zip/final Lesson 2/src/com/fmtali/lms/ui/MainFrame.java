package com.fmtali.lms.ui;

import com.fmtali.lms.model.Role;
import com.fmtali.lms.service.AttendanceService;
import com.fmtali.lms.service.AuthService;
import com.fmtali.lms.service.StudentService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

public class MainFrame extends JFrame {

    private final StudentService    service            = new StudentService();
    private final AttendanceService attendanceService  = new AttendanceService();

    public MainFrame(AuthService authService) {
        setTitle("Student Management System - FMTALI TECHNOLOGY");
        setSize(1100, 720);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        Color darkBg     = new Color(18, 18, 30);
        Color panelBg    = new Color(28, 28, 46);
        Color accentBlue = new Color(72, 130, 255);
        Color accentGold = new Color(255, 196, 64);

        getContentPane().setBackground(darkBg);
        setLayout(new BorderLayout(10, 10));

        // ── Header ──
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(panelBg);

        JPanel titleGroup = new JPanel();
        titleGroup.setLayout(new BoxLayout(titleGroup, BoxLayout.Y_AXIS));
        titleGroup.setBackground(panelBg);

        JLabel titleLbl = new JLabel("  Student Management System");
        titleLbl.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titleLbl.setForeground(accentBlue);

        JLabel subLbl = new JLabel("  Semester 1  —  Academic Year 2025");
        subLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subLbl.setForeground(accentGold);

        // Logged-in user label
        String userName = authService.getCurrentUser().getFullName();
        String userRole = authService.getCurrentUser().getRole().name();
        JLabel lblUser  = new JLabel("  Logged in as: "
            + userName + "  [" + userRole + "]");
        lblUser.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblUser.setForeground(new Color(140, 140, 165));

        // Real-time clock
        JLabel lblClock = new JLabel();
        lblClock.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblClock.setForeground(new Color(140, 140, 165));

        Timer clockTimer = new Timer(1000, e -> {
            java.time.LocalDateTime now = java.time.LocalDateTime.now();
            lblClock.setText(now.format(
                java.time.format.DateTimeFormatter
                    .ofPattern("dd MMM yyyy   HH:mm:ss")) + "  ");
        });
        clockTimer.setInitialDelay(0);
        clockTimer.start();

        titleGroup.add(titleLbl);
        titleGroup.add(subLbl);
        titleGroup.add(lblUser);

        // Logo
        JLabel logoLabel = new JLabel();
        logoLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        try {
            ImageIcon originalIcon = new ImageIcon("FMTALI_Logo.png");
            if (originalIcon.getIconWidth() > 0) {
                Image scaled = originalIcon.getImage()
                    .getScaledInstance(180, 55, Image.SCALE_SMOOTH);
                logoLabel.setIcon(new ImageIcon(scaled));
            } else {
                logoLabel.setText("FMTALI TECHNOLOGY");
                logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
                logoLabel.setForeground(accentGold);
            }
        } catch (Exception ex) {
            logoLabel.setText("FMTALI TECHNOLOGY");
            logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
            logoLabel.setForeground(accentGold);
        }

        header.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 2, 0, accentGold),
            new EmptyBorder(10, 20, 10, 20)
        ));
        header.add(titleGroup, BorderLayout.WEST);
        header.add(lblClock,   BorderLayout.CENTER);
        header.add(logoLabel,  BorderLayout.EAST);

        // ── Core panels ──
        DashboardPanel dashboard  = new DashboardPanel(service);
        TablePanel     tablePanel = new TablePanel(service);
        FormPanel      formPanel  = new FormPanel(service, tablePanel);

        tablePanel.setFormPanel(formPanel);
        tablePanel.setDashboardPanel(dashboard);

        // ── Role-based UI control ──
        Role   role       = authService.getCurrentUser().getRole();
        String viewerRole = role.name();

        // Apply restrictions to form based on role
        formPanel.setRole(viewerRole);

        // ── Students tab ──
        JPanel studentsTab = new JPanel(new BorderLayout(10, 10));
        studentsTab.setBackground(darkBg);
        studentsTab.add(dashboard,  BorderLayout.NORTH);
        studentsTab.add(formPanel,  BorderLayout.WEST);
        studentsTab.add(tablePanel, BorderLayout.CENTER);

        // ── Attendance tab ──
        AttendancePanel attendancePanel =
            new AttendancePanel(attendanceService, viewerRole);

        // ── Tabbed pane ──
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(panelBg);
        tabs.setForeground(accentGold);
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.addTab("  Students  ",   studentsTab);
        tabs.addTab("  Attendance  ", attendancePanel);

        // ── Bottom bar ──
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 16, 6));
        bottomBar.setBackground(panelBg);

        JLabel tip = new JLabel(
            "Tip: Click a row to select a student, then use Update or Delete.");
        tip.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        tip.setForeground(new Color(140, 140, 165));

        // Logout button on the right
        JButton btnLogout = new JButton("Logout");
        btnLogout.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnLogout.setBackground(new Color(210, 70, 70));
        btnLogout.setForeground(Color.WHITE);
        btnLogout.setFocusPainted(false);
        btnLogout.setBorderPainted(false);
        btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to logout?",
                "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                clockTimer.stop();
                authService.logout();
                dispose();
                new LoginFrame(authService);
            }
        });

        JPanel bottomRight = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        bottomRight.setBackground(panelBg);
        bottomRight.add(btnLogout);

        bottomBar.add(tip);
        bottomBar.setLayout(new BorderLayout());
        bottomBar.add(tip,         BorderLayout.WEST);
        bottomBar.add(bottomRight, BorderLayout.EAST);

        // ── Assemble frame ──
        add(header,  BorderLayout.NORTH);
        add(tabs,    BorderLayout.CENTER);
        add(bottomBar, BorderLayout.SOUTH);

        setVisible(true);
    }
}