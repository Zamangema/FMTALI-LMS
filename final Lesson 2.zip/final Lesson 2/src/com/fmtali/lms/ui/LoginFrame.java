package com.fmtali.lms.ui;

import com.fmtali.lms.model.User;
import com.fmtali.lms.service.AuthService;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

public class LoginFrame extends JFrame {

    private final Color darkBg     = new Color(18, 18, 30);
    private final Color panelBg    = new Color(28, 28, 46);
    private final Color accentBlue = new Color(72, 130, 255);
    private final Color accentGold = new Color(255, 196, 64);
    private final Color textWhite  = new Color(230, 230, 240);
    private final Color textGray   = new Color(140, 140, 165);

    private JTextField     txtID;
    private JPasswordField txtPassword;
    private JLabel         lblError;

    private final AuthService authService;

    public LoginFrame(AuthService authService) {
        this.authService = authService;
        buildUI();
        setTitle("FMTALI LMS — Login");
        setSize(440, 420);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setVisible(true);
    }

    private void buildUI() {
        getContentPane().setBackground(darkBg);

        // Use BorderLayout on the frame so the card fills it properly
        setLayout(new GridBagLayout());

        JPanel card = new JPanel();
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBackground(panelBg);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(accentBlue, 1, true),
            new EmptyBorder(28, 32, 28, 32)
        ));

        // ── Logo / title ──
        JLabel logoText = new JLabel("FMTALI");
        logoText.setFont(new Font("Segoe UI", Font.BOLD, 34));
        logoText.setForeground(accentGold);
        logoText.setAlignmentX(CENTER_ALIGNMENT);

        JLabel subText = new JLabel("Technology & Leadership Institute");
        subText.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subText.setForeground(textGray);
        subText.setAlignmentX(CENTER_ALIGNMENT);

        JLabel systemText = new JLabel("Learning Management System");
        systemText.setFont(new Font("Segoe UI", Font.BOLD, 13));
        systemText.setForeground(accentBlue);
        systemText.setAlignmentX(CENTER_ALIGNMENT);

        // ── ID field ──
        JLabel lblID = fieldLabel("ID Number / Username");
        txtID = makeTextField();

        // ── Password field ──
        JLabel lblPw = fieldLabel("Password");
        txtPassword = new JPasswordField();
        styleField(txtPassword);

        // ── Error label ──
        lblError = new JLabel(" ");
        lblError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        lblError.setForeground(new Color(220, 80, 80));
        lblError.setAlignmentX(CENTER_ALIGNMENT);
        lblError.setMaximumSize(new Dimension(Integer.MAX_VALUE, 20));

        // ── Login button ──
        JButton btnLogin = new JButton("LOGIN");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 15));
        btnLogin.setBackground(accentBlue);
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBorderPainted(false);
        btnLogin.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btnLogin.setMaximumSize(new Dimension(Integer.MAX_VALUE, 44));
        btnLogin.setAlignmentX(LEFT_ALIGNMENT);
        btnLogin.addActionListener(e -> handleLogin());
        btnLogin.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                btnLogin.setBackground(accentBlue.brighter());
            }
            public void mouseExited(MouseEvent e) {
                btnLogin.setBackground(accentBlue);
            }
        });

        // Press Enter on password field to login
        txtPassword.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER)
                    handleLogin();
            }
        });

        // ── Hint ──
        JLabel hint = new JLabel("Default password = your ID number");
        hint.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        hint.setForeground(textGray);
        hint.setAlignmentX(CENTER_ALIGNMENT);

        // ── Assemble card ──
        card.add(logoText);
        card.add(Box.createVerticalStrut(2));
        card.add(subText);
        card.add(Box.createVerticalStrut(2));
        card.add(systemText);
        card.add(Box.createVerticalStrut(24));
        card.add(lblID);
        card.add(Box.createVerticalStrut(5));
        card.add(txtID);
        card.add(Box.createVerticalStrut(12));
        card.add(lblPw);
        card.add(Box.createVerticalStrut(5));
        card.add(txtPassword);
        card.add(Box.createVerticalStrut(6));
        card.add(lblError);
        card.add(Box.createVerticalStrut(14));
        card.add(btnLogin);
        card.add(Box.createVerticalStrut(10));
        card.add(hint);

        add(card);
    }

       private void handleLogin() {
        String id       = txtID.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (id.isEmpty() || password.isEmpty()) {
            lblError.setText("Please enter your ID and password.");
            return;
        }

        User user = authService.login(id, password);

        if (user == null) {
            lblError.setText("Incorrect ID or password. Try again.");
            txtPassword.setText("");
            return;
        }

        // First login verification — must pass 'this' context while alive
        if (user.isFirstLogin()) {
            // FIX: Pass 'this' instead of 'null' so layout metrics apply properly
            ChangePasswordDialog dialog = new ChangePasswordDialog(this, authService, user.getId());
            dialog.setVisible(true); 

            // If they cancel or close without updating, disconnect session
            if (!dialog.isPasswordChanged()) {
                authService.logout();
                txtPassword.setText("");
                lblError.setText("Password change required to log in.");
                return;
            }
        }

        // Safe to close the login screen now
        dispose();

        // Pass control over to the Main application space
        new MainFrame(authService);
    }


    private JLabel fieldLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        l.setForeground(textGray);
        l.setAlignmentX(LEFT_ALIGNMENT);
        return l;
    }

    private JTextField makeTextField() {
        JTextField tf = new JTextField();
        styleField(tf);
        return tf;
    }

    private void styleField(JTextField tf) {
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tf.setBackground(new Color(45, 45, 70));
        tf.setForeground(textWhite);
        tf.setCaretColor(textWhite);
        tf.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(new Color(70, 70, 100), 1, true),
            new EmptyBorder(8, 10, 8, 10)
        ));
        tf.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        tf.setAlignmentX(LEFT_ALIGNMENT);
    }
}