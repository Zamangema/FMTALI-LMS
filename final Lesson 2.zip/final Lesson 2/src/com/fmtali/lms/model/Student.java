package com.fmtali.lms.model;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

public class Student {

    private String    studentID;
    private String    name;
    private String    email;
    private String    course;
    private LocalDate enrollDate;
    private String    status;

    // 3 individual project marks
    private double project1, project2, project3;

    // 7 test marks for Java, 5 for others
    // We store 7 slots — unused ones stay 0
    private double test1, test2, test3, test4,
                   test5, test6, test7;

    // Exam mark — only captured if student qualifies
    private double exam;

    // Whether student has been allowed to write exam
    private boolean examUnlocked;

    public Student(String studentID, String name, String email,
                   String course, LocalDate enrollDate, String status) {
        this.studentID   = studentID;
        this.name        = name;
        this.email       = email;
        this.course      = course;
        this.enrollDate  = enrollDate;
        this.status      = status;
        this.examUnlocked = false;
    }

    // ── Getters ──
    public String    getStudentID()   { return studentID; }
    public String    getName()        { return name; }
    public String    getEmail()       { return email; }
    public String    getCourse()      { return course; }
    public LocalDate getEnrollDate()  { return enrollDate; }
    public String    getStatus()      { return status; }
    public double    getProject1()    { return project1; }
    public double    getProject2()    { return project2; }
    public double    getProject3()    { return project3; }
    public double    getTest1()       { return test1; }
    public double    getTest2()       { return test2; }
    public double    getTest3()       { return test3; }
    public double    getTest4()       { return test4; }
    public double    getTest5()       { return test5; }
    public double    getTest6()       { return test6; }
    public double    getTest7()       { return test7; }
    public double    getExam()        { return exam; }
    public boolean   isExamUnlocked() { return examUnlocked; }

    // ── Setters ──
    public void setStudentID(String id)       { this.studentID  = id; }
    public void setName(String name)          { this.name       = name; }
    public void setEmail(String email)        { this.email      = email; }
    public void setCourse(String course)      { this.course     = course; }
    public void setEnrollDate(LocalDate date) { this.enrollDate = date; }
    public void setStatus(String status)      { this.status     = status; }
    public void setProject1(double v)         { this.project1   = v; }
    public void setProject2(double v)         { this.project2   = v; }
    public void setProject3(double v)         { this.project3   = v; }
    public void setTest1(double v)            { this.test1      = v; }
    public void setTest2(double v)            { this.test2      = v; }
    public void setTest3(double v)            { this.test3      = v; }
    public void setTest4(double v)            { this.test4      = v; }
    public void setTest5(double v)            { this.test5      = v; }
    public void setTest6(double v)            { this.test6      = v; }
    public void setTest7(double v)            { this.test7      = v; }
    public void setExam(double v)             { this.exam       = v; }
    public void setExamUnlocked(boolean v)    { this.examUnlocked = v; }

    // ── Project mark — best 2 out of 3 averaged ──
    public double getProjectMark() {
        double[] p = {project1, project2, project3};
        Arrays.sort(p);
        // best 2 = last two after sort
        return (p[1] + p[2]) / 2.0;
    }

    // ── Test mark — best 5 of 7 (Java) or best 3 of 5 (others) ──
    public double getTestMark() {
        if (course.equalsIgnoreCase("Java")) {
            double[] t = {test1, test2, test3, test4, test5, test6, test7};
            Arrays.sort(t);
            // best 5 = last 5
            return (t[2] + t[3] + t[4] + t[5] + t[6]) / 5.0;
        } else {
            double[] t = {test1, test2, test3, test4, test5};
            Arrays.sort(t);
            // best 3 = last 3
            return (t[2] + t[3] + t[4]) / 3.0;
        }
    }

    // ── Combined mark (project + test averaged) ──
    public double getCombinedMark() {
        return (getProjectMark() + getTestMark()) / 2.0;
    }

    // ── Qualifies to write exam if combined >= 50 ──
    public boolean qualifiesForExam() {
        return getCombinedMark() >= 50.0;
    }

    // ── Final mark: Project 20% + Test 30% + Exam 50% ──
    // Only meaningful if exam has been written
    public double getFinalMark() {
        return (getProjectMark() * 0.20)
             + (getTestMark()    * 0.30)
             + (exam             * 0.50);
    }

    // ── Pass mark per course ──
    public double getPassMark() {
        return course.equalsIgnoreCase("Java") ? 65.0 : 70.0;
    }

    // ── Auto grade from final mark ──
    public String getGrade() {
        if (!examUnlocked) return "—"; // no grade until exam written
        double m = getFinalMark();
        if (m >= 80) return "A";
        if (m >= 70) return "B";
        if (m >= 60) return "C";
        if (m >= 50) return "D";
        return "F";
    }

    // ── Auto graduation ──
    public boolean isGraduated() {
        return examUnlocked && getFinalMark() >= getPassMark();
    }

    // ── Auto status — never overrides Suspended/Dropped ──
    public String computeStatus() {
        if (status.equals("Suspended") || status.equals("Dropped"))
            return status;
        if (isGraduated()) return "Graduated";
        return "Active";
    }

    // ── Number of tests for this course ──
    public int getTestCount() {
        return course.equalsIgnoreCase("Java") ? 7 : 5;
    }

    public String getFormattedEnrollDate() {
        return enrollDate.format(
            DateTimeFormatter.ofPattern("MMMM dd, yyyy"));
    }

    public String getEnrollmentDuration() {
        Period p = Period.between(enrollDate, LocalDate.now());
        if (p.getYears() > 0 && p.getMonths() > 0)
            return "Enrolled for " + p.getYears() + "yr "
                + p.getMonths() + "mo";
        else if (p.getYears() > 0)
            return "Enrolled for " + p.getYears() + " year(s)";
        else if (p.getMonths() > 0)
            return "Enrolled for " + p.getMonths() + " month(s)";
        else
            return "Enrolled for " + p.getDays() + " day(s)";
    }
}