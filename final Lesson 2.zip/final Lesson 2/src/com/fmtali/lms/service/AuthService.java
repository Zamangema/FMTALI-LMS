package com.fmtali.lms.service;

import com.fmtali.lms.model.Role;
import com.fmtali.lms.model.User;
import com.fmtali.lms.util.PasswordUtil;

import java.util.ArrayList;
import java.util.List;

// Handles login, logout, account creation, password changes
// Phase 2: replace ArrayList with PostgreSQL users table
public class AuthService {

    private final List<User> users = new ArrayList<>();
    private User currentUser = null;

    public AuthService() {
        // Pre-load default accounts for testing
        // Phase 2: these come from the database instead
        seedDefaultAccounts();
    }

    // ── Seed default accounts ──
    private void seedDefaultAccounts() {

        // Admin account — username: admin, password: admin
        // (admin can change this after first login)
        users.add(new User(
            "admin",
            "System Administrator",
            PasswordUtil.hash("admin"),
            Role.ADMIN
        ));

        // Example facilitator — ID is their username + default password
        users.add(new User(
            "FAC001",
            "Facilitator One",
            PasswordUtil.hash("FAC001"),
            Role.FACILITATOR
        ));

        // Example student — SA ID number as username + default password
        users.add(new User(
            "0001010000000",
            "John Smith",
            PasswordUtil.hash("0001010000000"),
            Role.STUDENT
        ));
    }

    // ── Login ──
    // Returns the User if successful, null if wrong credentials
    public User login(String id, String password) {
        for (User u : users) {
            if (u.getId().equalsIgnoreCase(id.trim())) {
                if (PasswordUtil.verify(password, u.getPasswordHash())) {
                    currentUser = u;
                    return u;
                } else {
                    return null; // wrong password
                }
            }
        }
        return null; // user not found
    }

    // ── Logout ──
    public void logout() {
        currentUser = null;
    }

    // ── Change password ──
    public boolean changePassword(String userId,
                                  String newPassword) {
        for (User u : users) {
            if (u.getId().equalsIgnoreCase(userId)) {
                u.setPasswordHash(PasswordUtil.hash(newPassword));
                u.setFirstLogin(false);
                return true;
            }
        }
        return false;
    }

    // ── Create new account (Admin only) ──
    public boolean createAccount(String id, String fullName, Role role) {
        // Check if ID already exists
        for (User u : users) {
            if (u.getId().equalsIgnoreCase(id)) return false;
        }
        // Default password = their ID
        users.add(new User(id, fullName,
            PasswordUtil.hash(id), role));
        return true;
    }

    // ── Get current logged-in user ──
    public User getCurrentUser() { return currentUser; }

    // ── Get all users (Admin use) ──
    public List<User> getAllUsers() { return users; }

    // ── Find user by ID ──
    public User findById(String id) {
        return users.stream()
            .filter(u -> u.getId().equalsIgnoreCase(id))
            .findFirst()
            .orElse(null);
    }
}