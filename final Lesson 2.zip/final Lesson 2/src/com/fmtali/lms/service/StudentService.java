package com.fmtali.lms.service;

import com.fmtali.lms.model.Student;
import java.util.ArrayList;
import java.util.List;

public class StudentService {

    private final List<Student> studentList = new ArrayList<>();

    public void addStudent(Student student) {
        studentList.add(student);
    }

    public void updateStudent(int index, Student updated) {
        studentList.set(index, updated);
    }

    public void deleteStudent(int index) {
        studentList.remove(index);
    }

    public Student getStudent(int index) {
        return studentList.get(index);
    }

    public List<Student> getAllStudents() {
        return studentList;
    }

    public boolean studentIDExists(String id) {
        return studentList.stream()
            .anyMatch(s -> s.getStudentID().equalsIgnoreCase(id));
    }

    public int getTotalStudents() {
        return studentList.size();
    }

    public long getCountByCourse(String course) {
        return studentList.stream()
            .filter(s -> s.getCourse().equalsIgnoreCase(course))
            .count();
    }

    // Check and unlock exam if student qualifies
    // Returns true if newly unlocked
    public boolean checkAndUnlockExam(Student s) {
        if (!s.isExamUnlocked() && s.qualifiesForExam()) {
            s.setExamUnlocked(true);
            return true;
        }
        return false;
    }
}