package com.fmtali.lms.service;

import com.fmtali.lms.model.Attendance;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class AttendanceService {

    // Campus coordinates — FMTALI Technology
    private static final double CAMPUS_LAT = -26.0990;
    private static final double CAMPUS_LNG =  27.9988;

    // Allowed radius in metres (200m = roughly one campus block)
    private static final double ALLOWED_RADIUS_METRES = 200.0;

    // In Phase 2 this becomes a database table
    private final List<Attendance> records = new ArrayList<>();

    // ── Sign In ──
    // Returns null if already signed in today
    public Attendance signIn(String personID, String personName,
                             String role, double latitude, double longitude) {

        // Check if already signed in today
        if (isAlreadySignedInToday(personID)) {
            return null;
        }

        String locationStatus = isOnCampus(latitude, longitude)
            ? "On Campus" : "Off Campus";

        Attendance record = new Attendance(
            personID, personName, role,
            LocalDate.now(), LocalTime.now(),
            latitude, longitude, locationStatus
        );

        records.add(record);
        return record;
    }

    // ── Sign Out ──
    // Returns false if no sign-in found for today
    public boolean signOut(String personID) {
        Attendance record = getTodayRecord(personID);
        if (record == null || record.isSignedOut()) return false;
        record.signOut(LocalTime.now());
        return true;
    }

    // ── Get all records (Admin sees everything) ──
    public List<Attendance> getAllRecords() {
        return records;
    }

    // ── Get student records only (Facilitator view) ──
    public List<Attendance> getStudentRecords() {
        return records.stream()
            .filter(a -> a.getRole().equals("Student"))
            .collect(Collectors.toList());
    }

    // ── Get records for a specific person ──
    public List<Attendance> getRecordsForPerson(String personID) {
        return records.stream()
            .filter(a -> a.getPersonID().equals(personID))
            .collect(Collectors.toList());
    }

    // ── Get today's records only ──
    public List<Attendance> getTodayRecords() {
        LocalDate today = LocalDate.now();
        return records.stream()
            .filter(a -> a.getDate().equals(today))
            .collect(Collectors.toList());
    }

    // ── Check if person already signed in today ──
    public boolean isAlreadySignedInToday(String personID) {
        return getTodayRecord(personID) != null;
    }

    // ── Get today's record for a person ──
    public Attendance getTodayRecord(String personID) {
        LocalDate today = LocalDate.now();
        return records.stream()
            .filter(a -> a.getPersonID().equals(personID)
                      && a.getDate().equals(today))
            .findFirst()
            .orElse(null);
    }

    // ── Attendance percentage for a student ──
    public double getAttendancePercentage(String personID, int totalClasses) {
        if (totalClasses == 0) return 0;
        long attended = records.stream()
            .filter(a -> a.getPersonID().equals(personID)
                      && !a.getStatus().equals("Absent"))
            .count();
        return (attended * 100.0) / totalClasses;
    }

    // ── Geofence check ──
    // Uses Haversine formula to calculate distance between two GPS points
    public static boolean isOnCampus(double lat, double lng) {
        double distanceMetres = haversine(
            CAMPUS_LAT, CAMPUS_LNG, lat, lng);
        return distanceMetres <= ALLOWED_RADIUS_METRES;
    }

    public static double getDistanceFromCampus(double lat, double lng) {
        return haversine(CAMPUS_LAT, CAMPUS_LNG, lat, lng);
    }

    // Haversine formula — calculates distance in metres between two coordinates
    private static double haversine(double lat1, double lon1,
                                    double lat2, double lon2) {
        final double R = 6371000; // Earth radius in metres
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(Math.toRadians(lat1))
                 * Math.cos(Math.toRadians(lat2))
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }
}