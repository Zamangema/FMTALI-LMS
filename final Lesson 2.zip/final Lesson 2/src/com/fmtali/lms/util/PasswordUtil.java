package com.fmtali.lms.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

// Handles password hashing and validation rules
// Phase 3: swap hash() for BCrypt when moving to Spring Boot
public class PasswordUtil {

    // Hash a password using SHA-256
    // In Spring Boot we replace this with BCryptPasswordEncoder
    public static String hash(String plainText) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(plainText.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : bytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    // Check plain text against stored hash
    public static boolean verify(String plainText, String storedHash) {
        return hash(plainText).equals(storedHash);
    }

    // Password strength rules
    public static boolean isStrongPassword(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasUpper  = password.chars()
            .anyMatch(Character::isUpperCase);
        boolean hasDigit  = password.chars()
            .anyMatch(Character::isDigit);
        boolean hasSpecial = password.chars()
            .anyMatch(c -> "!@#$%^&*()_+-=[]{}".indexOf(c) >= 0);
        return hasUpper && hasDigit && hasSpecial;
    }

    // Password must not be the same as their ID
    public static boolean isSameAsID(String password, String id) {
        return password.trim().equalsIgnoreCase(id.trim());
    }

    public static String getPasswordRules() {
        return "Password must be:\n"
             + "• At least 8 characters\n"
             + "• At least one uppercase letter\n"
             + "• At least one number\n"
             + "• At least one special character (!@#$%)\n"
             + "• Not the same as your ID number";
    }
}