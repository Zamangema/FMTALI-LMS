package com.fmtali.lms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    // ── Change these to match your PostgreSQL setup ──
    private static final String URL      =
        "jdbc:postgresql://localhost:5432/fmtali_lms";
    private static final String USER     = "postgres";
    private static final String PASSWORD = "your_password_here"; // ← your pgAdmin password

    private static Connection connection = null;

    // Returns a single shared connection (singleton)
    public static Connection getConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                connection = DriverManager.getConnection(
                    URL, USER, PASSWORD);
                System.out.println("✓ Connected to PostgreSQL");
            }
        } catch (SQLException e) {
            System.err.println("✗ Database connection failed: "
                + e.getMessage());
        }
        return connection;
    }

    public static void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
                System.out.println("✓ Database connection closed");
            }
        } catch (SQLException e) {
            System.err.println("Error closing connection: "
                + e.getMessage());
        }
    }
}