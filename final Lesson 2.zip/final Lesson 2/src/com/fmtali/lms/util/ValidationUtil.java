package com.fmtali.lms.util;

import javax.swing.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class ValidationUtil {

    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd");

    public static boolean isNullOrEmpty(String value) {
        return value == null || value.trim().isEmpty();
    }

    public static boolean isValidEmail(String email) {
        return email != null && email.contains("@") && email.contains(".");
    }

    public static LocalDate parseDate(String dateStr, JComponent parent) {
        try {
            return LocalDate.parse(dateStr.trim(), DATE_FMT);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(parent,
                "Invalid date format! Use YYYY-MM-DD (e.g. 2024-02-15).",
                "Input Error", JOptionPane.ERROR_MESSAGE);
            return null;
        }
    }

    public static void showError(JComponent parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg,
            "Input Error", JOptionPane.ERROR_MESSAGE);
    }
}